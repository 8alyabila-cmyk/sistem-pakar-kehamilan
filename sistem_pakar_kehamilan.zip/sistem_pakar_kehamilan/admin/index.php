<?php
declare(strict_types=1);
require __DIR__ . '/_auth.php';

$hitung = static function (string $tabel) use ($pdo): int {
    return (int) $pdo->query("SELECT COUNT(*) FROM $tabel")->fetchColumn(); // nama tabel tetap (bukan input)
};
$stat = [
    ['Penyakit',           $hitung('penyakit')],
    ['Gejala',             $hitung('gejala')],
    ['Relasi aturan',      $hitung('relasi')],
    ['Konsultasi tercatat', $hitung('konsultasi')],
];
$belumValid = (int) $pdo->query('SELECT COUNT(*) FROM penyakit WHERE solusi_tervalidasi = 0')->fetchColumn();
$terbaru    = $pdo->query('SELECT token, dibuat, nama_ibu, diagnosis_nama, diagnosis_persen FROM konsultasi ORDER BY id DESC LIMIT 5')->fetchAll();

admin_top('Dashboard', 'dashboard');
?>
<div class="stat-grid">
  <?php foreach ($stat as [$label, $angka]): ?>
    <div class="kartu stat"><div class="angka"><?= $angka ?></div><div class="label"><?= e($label) ?></div></div>
  <?php endforeach; ?>
</div>

<?php if ($belumValid > 0): ?>
  <div class="notif" style="background:var(--peringatan-bg);color:#5E3A00;border-color:#EBD8B0">
    <?= $belumValid ?> penyakit belum memiliki solusi medis yang divalidasi pakar.
    <a href="solusi.php">Kelola Solusi Medis</a>
  </div>
<?php endif; ?>

<h2 class="sub-judul">Konsultasi terbaru</h2>
<div class="tabel-wadah">
  <table class="tabel">
    <thead><tr><th>Tanggal</th><th>Nama Ibu Hamil</th><th>Diagnosis Tertinggi</th><th>Nilai CF</th></tr></thead>
    <tbody>
      <?php foreach ($terbaru as $r): ?>
        <tr>
          <td><?= e(tanggal_id($r['dibuat'])) ?></td>
          <td><a href="../hasil.php?t=<?= e($r['token']) ?>"><?= e($r['nama_ibu']) ?></a></td>
          <td><?= e($r['diagnosis_nama'] ?? '-') ?></td>
          <td><?= $r['diagnosis_nama'] ? e(number_format((float) $r['diagnosis_persen'], 2, ',', '.')) . '%' : '-' ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$terbaru): ?><tr><td colspan="4" class="kosong">Belum ada konsultasi.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php admin_bottom();
