<?php
declare(strict_types=1);
require __DIR__ . '/_auth.php';

$galat = [];
$form  = ['mode' => 'tambah', 'kode_lama' => '', 'kode' => '', 'nama' => '', 'deskripsi' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_cek();
    $op = (string) ($_POST['op'] ?? '');

    if ($op === 'hapus') {
        $kode = (string) ($_POST['kode'] ?? '');
        $st = $pdo->prepare('DELETE FROM penyakit WHERE kode = ?');
        $st->execute([$kode]);
        flash_set('ok', "Penyakit $kode dihapus beserta relasi gejalanya.");
        redirect('penyakit.php');
    }

    if ($op === 'simpan') {
        $form = [
            'mode'      => ($_POST['mode'] ?? '') === 'edit' ? 'edit' : 'tambah',
            'kode_lama' => (string) ($_POST['kode_lama'] ?? ''),
            'kode'      => strtoupper(trim((string) ($_POST['kode'] ?? ''))),
            'nama'      => trim((string) ($_POST['nama'] ?? '')),
            'deskripsi' => trim((string) ($_POST['deskripsi'] ?? '')),
        ];
        if (!preg_match('/^P\d{3}$/', $form['kode'])) {
            $galat['kode'] = 'Kode harus berformat P diikuti 3 angka, mis. P009.';
        }
        if ($form['nama'] === '' || strlen($form['nama']) > 120) {
            $galat['nama'] = 'Nama penyakit wajib diisi (maksimal 120 karakter).';
        }
        if ($form['deskripsi'] === '') {
            $galat['deskripsi'] = 'Deskripsi medis wajib diisi.';
        }

        if (!$galat) {
            try {
                if ($form['mode'] === 'edit') {
                    $st = $pdo->prepare('UPDATE penyakit SET kode = ?, nama = ?, deskripsi = ? WHERE kode = ?');
                    $st->execute([$form['kode'], $form['nama'], $form['deskripsi'], $form['kode_lama']]);
                    flash_set('ok', 'Data penyakit diperbarui.');
                } else {
                    $st = $pdo->prepare('INSERT INTO penyakit (kode, nama, deskripsi) VALUES (?, ?, ?)');
                    $st->execute([$form['kode'], $form['nama'], $form['deskripsi']]);
                    flash_set('ok', 'Penyakit baru ditambahkan. Lanjutkan dengan mengisi relasi gejala di menu Bobot CF Pakar.');
                }
                redirect('penyakit.php');
            } catch (PDOException $ex) {
                if ($ex->getCode() === '23000') {
                    $galat['kode'] = 'Kode sudah digunakan.';
                } else {
                    error_log($ex->getMessage());
                    $galat['umum'] = 'Gagal menyimpan data.';
                }
            }
        }
    }
}

$aksi = (string) ($_GET['aksi'] ?? '');
if ($_SERVER['REQUEST_METHOD'] === 'GET' && $aksi === 'edit') {
    $st = $pdo->prepare('SELECT kode, nama, deskripsi FROM penyakit WHERE kode = ?');
    $st->execute([(string) ($_GET['kode'] ?? '')]);
    if ($r = $st->fetch()) {
        $form = ['mode' => 'edit', 'kode_lama' => $r['kode'], 'kode' => $r['kode'], 'nama' => $r['nama'], 'deskripsi' => $r['deskripsi']];
    } else {
        flash_set('err', 'Penyakit tidak ditemukan.');
        redirect('penyakit.php');
    }
}
$tampilForm = $aksi === 'tambah' || $aksi === 'edit' || $galat;

if ($tampilForm) {
    admin_top($form['mode'] === 'edit' ? 'Edit Penyakit' : 'Tambah Penyakit', 'penyakit');
    ?>
<div class="panel lebar">
  <?php if (isset($galat['umum'])): ?><div class="notif notif-err"><?= e($galat['umum']) ?></div><?php endif; ?>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="op" value="simpan">
    <input type="hidden" name="mode" value="<?= e($form['mode']) ?>">
    <input type="hidden" name="kode_lama" value="<?= e($form['kode_lama']) ?>">

    <div class="field">
      <label for="kode">Kode</label>
      <input class="input" id="kode" name="kode" maxlength="4" required value="<?= e($form['kode']) ?>" placeholder="P009">
      <?php if (isset($galat['kode'])): ?><div class="field-error"><?= e($galat['kode']) ?></div><?php endif; ?>
    </div>
    <div class="field">
      <label for="nama">Nama penyakit</label>
      <input class="input" id="nama" name="nama" maxlength="120" required value="<?= e($form['nama']) ?>">
      <?php if (isset($galat['nama'])): ?><div class="field-error"><?= e($galat['nama']) ?></div><?php endif; ?>
    </div>
    <div class="field">
      <label for="deskripsi">Deskripsi medis</label>
      <textarea class="input" id="deskripsi" name="deskripsi" required><?= e($form['deskripsi']) ?></textarea>
      <?php if (isset($galat['deskripsi'])): ?><div class="field-error"><?= e($galat['deskripsi']) ?></div><?php endif; ?>
    </div>
    <div class="baris-tombol">
      <button type="submit" class="tombol tombol-utama tombol-kecil">Simpan</button>
      <a class="tombol tombol-kecil" href="penyakit.php">Batal</a>
    </div>
  </form>
</div>
<?php
    admin_bottom();
    exit;
}

$daftar = $pdo->query(
    'SELECT p.kode, p.nama, p.deskripsi, (SELECT COUNT(*) FROM relasi r WHERE r.kode_penyakit = p.kode) AS jml
       FROM penyakit p ORDER BY p.kode'
)->fetchAll();

admin_top('Kelola Penyakit', 'penyakit', ['label' => 'Tambah Penyakit', 'href' => '?aksi=tambah']);
?>
<div class="tabel-wadah">
  <table class="tabel">
    <thead><tr><th style="width:100px">Kode</th><th style="width:260px">Nama Penyakit</th><th>Deskripsi Medis</th><th style="width:80px">Gejala</th><th style="width:150px">Aksi</th></tr></thead>
    <tbody>
      <?php foreach ($daftar as $d): ?>
        <tr>
          <td><span class="badge-kode"><?= e($d['kode']) ?></span></td>
          <td><strong><?= e($d['nama']) ?></strong></td>
          <td class="redup"><?= e($d['deskripsi']) ?></td>
          <td><?= (int) $d['jml'] ?></td>
          <td>
            <div class="aksi-sel">
              <a class="tautan-aksi" href="?aksi=edit&amp;kode=<?= urlencode($d['kode']) ?>">Edit</a>
              <form method="post" data-konfirmasi="Hapus <?= e($d['kode']) ?> beserta seluruh relasi gejalanya?">
                <?= csrf_field() ?><input type="hidden" name="op" value="hapus"><input type="hidden" name="kode" value="<?= e($d['kode']) ?>">
                <button type="submit" class="tautan-aksi bahaya">Hapus</button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$daftar): ?><tr><td colspan="5" class="kosong">Belum ada data penyakit.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php admin_bottom();
