<?php
declare(strict_types=1);
require __DIR__ . '/_auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_cek();
    if (($_POST['op'] ?? '') === 'hapus') {
        $st = $pdo->prepare('DELETE FROM konsultasi WHERE id = ?');
        $st->execute([(int) ($_POST['id'] ?? 0)]);
        flash_set('ok', 'Riwayat konsultasi dihapus.');
    }
    redirect('riwayat.php');
}

$perHal = 20;
$total  = (int) $pdo->query('SELECT COUNT(*) FROM konsultasi')->fetchColumn();
$jmlHal = max(1, (int) ceil($total / $perHal));
$hal    = min($jmlHal, max(1, (int) ($_GET['hal'] ?? 1)));
$offset = ($hal - 1) * $perHal;

$st = $pdo->prepare(
    'SELECT id, token, dibuat, nama_ibu, diagnosis_nama, diagnosis_cf, diagnosis_persen, diagnosis_kategori
       FROM konsultasi ORDER BY id DESC LIMIT ' . (int) $perHal . ' OFFSET ' . (int) $offset
);
$st->execute();
$daftar = $st->fetchAll();

admin_top('Riwayat Diagnosis', 'riwayat');
?>
<div class="tabel-wadah">
  <table class="tabel">
    <thead><tr><th style="width:260px">Tanggal</th><th style="width:250px">Nama Ibu Hamil</th><th>Diagnosis Tertinggi</th><th style="width:210px">Nilai CF</th><th style="width:90px">Aksi</th></tr></thead>
    <tbody>
      <?php foreach ($daftar as $d): ?>
        <tr>
          <td><?= e(tanggal_id($d['dibuat'])) ?></td>
          <td><a href="../hasil.php?t=<?= e($d['token']) ?>" target="_blank" rel="noopener"><?= e($d['nama_ibu']) ?></a></td>
          <td><?= e($d['diagnosis_nama'] ?? 'Tidak ada yang cocok') ?></td>
          <td>
            <?php if ($d['diagnosis_nama']): ?>
              <?= e(format_cf((float) $d['diagnosis_cf'])) ?> · <?= e(format_persen((float) $d['diagnosis_cf'])) ?>
              <?php $kr = kategori_cf((float) $d['diagnosis_cf']); ?>
              <span class="badge-kategori kat-<?= e($kr['kelas']) ?>" style="margin-left:6px"><?= e($kr['label']) ?></span>
            <?php else: ?>-<?php endif; ?>
          </td>
          <td>
            <form method="post" data-konfirmasi="Hapus riwayat konsultasi ini?">
              <?= csrf_field() ?><input type="hidden" name="op" value="hapus"><input type="hidden" name="id" value="<?= (int) $d['id'] ?>">
              <button type="submit" class="tautan-aksi bahaya">Hapus</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$daftar): ?><tr><td colspan="5" class="kosong">Belum ada riwayat konsultasi.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<?php if ($jmlHal > 1): ?>
  <nav class="halaman-nav" aria-label="Halaman">
    <?php if ($hal > 1): ?><a class="tautan-aksi" href="?hal=<?= $hal - 1 ?>">&larr; Sebelumnya</a><?php endif; ?>
    <span class="redup">Halaman <?= $hal ?> dari <?= $jmlHal ?> · <?= $total ?> data</span>
    <?php if ($hal < $jmlHal): ?><a class="tautan-aksi" href="?hal=<?= $hal + 1 ?>">Berikutnya &rarr;</a><?php endif; ?>
  </nav>
<?php endif; ?>
<?php admin_bottom();
