<?php
declare(strict_types=1);
require __DIR__ . '/_auth.php';

$galat = '';
$kodeEdit = (string) ($_GET['kode'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_cek();
    $kodeEdit = (string) ($_POST['kode'] ?? '');
    $solusi   = trim((string) ($_POST['solusi'] ?? ''));
    $valid    = isset($_POST['tervalidasi']) ? 1 : 0;

    if ($valid === 1 && $solusi === '') {
        $galat = 'Materi solusi harus diisi sebelum ditandai tervalidasi.';
    } else {
        $st = $pdo->prepare('UPDATE penyakit SET solusi = ?, solusi_tervalidasi = ? WHERE kode = ?');
        $st->execute([$solusi === '' ? null : $solusi, $valid, $kodeEdit]);
        flash_set('ok', 'Solusi medis ' . $kodeEdit . ' disimpan' . ($valid ? ' dan ditandai tervalidasi.' : ' (belum tervalidasi, tidak ditampilkan ke pengguna).'));
        redirect('solusi.php');
    }
}

if ($kodeEdit !== '') {
    $st = $pdo->prepare('SELECT kode, nama, solusi, solusi_tervalidasi FROM penyakit WHERE kode = ?');
    $st->execute([$kodeEdit]);
    $p = $st->fetch();
    if (!$p) {
        flash_set('err', 'Penyakit tidak ditemukan.');
        redirect('solusi.php');
    }
    $nilaiSolusi = $_SERVER['REQUEST_METHOD'] === 'POST' ? (string) ($_POST['solusi'] ?? '') : (string) $p['solusi'];
    $nilaiValid  = $_SERVER['REQUEST_METHOD'] === 'POST' ? isset($_POST['tervalidasi']) : (int) $p['solusi_tervalidasi'] === 1;

    admin_top('Edit Solusi Medis', 'solusi');
    ?>
<div class="panel lebar">
  <h2><span class="badge-kode"><?= e($p['kode']) ?></span> <?= e($p['nama']) ?></h2>
  <?php if ($galat): ?><div class="notif notif-err"><?= e($galat) ?></div><?php endif; ?>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="kode" value="<?= e($p['kode']) ?>">
    <div class="field">
      <label for="solusi">Solusi medis / tindak lanjut</label>
      <textarea class="input" id="solusi" name="solusi" rows="7"><?= e($nilaiSolusi) ?></textarea>
    </div>
    <div class="field">
      <label class="cek"><input type="checkbox" name="tervalidasi" value="1"<?= $nilaiValid ? ' checked' : '' ?>> Sudah divalidasi oleh pakar medis</label>
      <div class="bantuan">Selama belum dicentang, pengguna hanya melihat teks “<?= e(TEKS_SOLUSI_BELUM) ?>”.</div>
    </div>
    <div class="baris-tombol">
      <button type="submit" class="tombol tombol-utama tombol-kecil">Simpan</button>
      <a class="tombol tombol-kecil" href="solusi.php">Batal</a>
    </div>
  </form>
</div>
<?php
    admin_bottom();
    exit;
}

$daftar = $pdo->query('SELECT kode, nama, solusi, solusi_tervalidasi FROM penyakit ORDER BY kode')->fetchAll();

admin_top('Solusi Medis', 'solusi');
?>
<div class="daftar-solusi">
  <?php foreach ($daftar as $d):
      $valid = (int) $d['solusi_tervalidasi'] === 1 && trim((string) $d['solusi']) !== ''; ?>
    <div class="solusi-item">
      <div class="solusi-kepala">
        <div class="kiri">
          <span class="badge-kode"><?= e($d['kode']) ?></span>
          <h3><?= e($d['nama']) ?></h3>
          <span class="badge-status <?= $valid ? 'status-ok' : 'status-belum' ?>"><?= $valid ? 'Tervalidasi' : 'Belum divalidasi' ?></span>
        </div>
        <a class="tautan-aksi" href="?kode=<?= urlencode($d['kode']) ?>">Edit Solusi</a>
      </div>
      <p><?= $valid ? e(mb_strimwidth((string) $d['solusi'], 0, 220, '…', 'UTF-8')) : e(TEKS_SOLUSI_BELUM) ?></p>
    </div>
  <?php endforeach; ?>
  <?php if (!$daftar): ?><div class="kosong">Belum ada penyakit.</div><?php endif; ?>
</div>
<?php admin_bottom();
