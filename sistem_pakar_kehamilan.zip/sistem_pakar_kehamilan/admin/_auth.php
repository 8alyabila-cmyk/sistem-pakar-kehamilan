<?php
declare(strict_types=1);

/**
 * Di-include oleh semua halaman admin (kecuali login.php).
 * Memastikan sesi admin valid, lalu menyediakan $pdo.
 */
require_once __DIR__ . '/../includes/init.php';

const ADMIN_IDLE_MAKS = 7200; // 2 jam tanpa aktivitas -> keluar otomatis

if (empty($_SESSION['admin_id'])) {
    redirect('login.php');
}
if (isset($_SESSION['admin_aktif']) && time() - (int) $_SESSION['admin_aktif'] > ADMIN_IDLE_MAKS) {
    $_SESSION = [];
    session_regenerate_id(true);
    flash_set('err', 'Sesi berakhir karena tidak ada aktivitas. Silakan masuk kembali.');
    redirect('login.php');
}
$_SESSION['admin_aktif'] = time();

$pdo = db();
