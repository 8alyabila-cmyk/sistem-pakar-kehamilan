<?php
declare(strict_types=1);
require __DIR__ . '/../includes/init.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_cek();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $c = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $c['path'], $c['domain'] ?? '', (bool) $c['secure'], (bool) $c['httponly']);
    }
    session_destroy();
    session_start();
    session_regenerate_id(true);
    flash_set('ok', 'Anda telah keluar.');
}
redirect('login.php');
