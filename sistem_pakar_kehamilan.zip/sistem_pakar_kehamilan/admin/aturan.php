<?php
declare(strict_types=1);
require __DIR__ . '/_auth.php';

/**
 * Manajemen aturan: aturan IF-THEN dibangkitkan otomatis dari tabel relasi,
 * sehingga mengubah relasi/bobot di menu "Bobot CF Pakar" langsung mengubah aturan.
 */
$penyakit = $pdo->query('SELECT kode, nama FROM penyakit ORDER BY kode')->fetchAll();
$relasi   = $pdo->query('SELECT kode_penyakit, kode_gejala FROM relasi ORDER BY kode_penyakit, kode_gejala')->fetchAll();

$premis = [];
foreach ($relasi as $r) {
    $premis[$r['kode_penyakit']][] = $r['kode_gejala'];
}

admin_top('Aturan IF-THEN', 'aturan');
?>
<p class="redup" style="max-width:820px;margin-bottom:20px">
  Basis aturan untuk <strong>forward chaining</strong>. Setiap gejala pada sebuah aturan yang dijawab pengguna akan
  menyalakan aturan tersebut, lalu CF tiap gejala digabung dengan rumus
  <em>CF₁ + CF₂ × (1 − CF₁)</em>. Ubah aturan melalui menu <a href="bobot_cf.php">Bobot CF Pakar</a>.
</p>

<div class="daftar-aturan">
  <?php foreach ($penyakit as $i => $p):
      $gs = $premis[$p['kode']] ?? []; ?>
    <div class="aturan">
      <div class="ekspresi">
        <span class="rid">R<?= str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT) ?></span>
        <?php if ($gs): ?>
          <span class="kw">IF</span> <?= e(implode(' AND ', $gs)) ?>
          <span class="kw">THEN</span> <?= e($p['kode']) ?> <span class="redup">(<?= e($p['nama']) ?>)</span>
        <?php else: ?>
          <span class="redup"><?= e($p['kode']) ?> (<?= e($p['nama']) ?>) belum memiliki gejala.</span>
        <?php endif; ?>
      </div>
      <a class="tautan-aksi" href="bobot_cf.php?penyakit=<?= urlencode($p['kode']) ?>">Kelola (<?= count($gs) ?> gejala)</a>
    </div>
  <?php endforeach; ?>
  <?php if (!$penyakit): ?><div class="kosong">Belum ada penyakit.</div><?php endif; ?>
</div>
<?php admin_bottom();
