<?php
declare(strict_types=1);
require __DIR__ . '/_auth.php';

$galat = [];
$user  = '';

$st = $pdo->prepare('SELECT username FROM admin WHERE id = ?');
$st->execute([(int) $_SESSION['admin_id']]);
$user = (string) ($st->fetchColumn() ?: '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_cek();
    $userBaru = trim((string) ($_POST['username'] ?? ''));
    $lama     = (string) ($_POST['password_lama'] ?? '');
    $baru     = (string) ($_POST['password_baru'] ?? '');

    $st = $pdo->prepare('SELECT password_hash FROM admin WHERE id = ?');
    $st->execute([(int) $_SESSION['admin_id']]);
    $hash = (string) $st->fetchColumn();

    if (!preg_match('/^[A-Za-z0-9_.-]{3,50}$/', $userBaru)) {
        $galat['username'] = 'Username 3-50 karakter (huruf, angka, titik, garis bawah, atau strip).';
    }
    if (!password_verify($lama, $hash)) {
        $galat['password_lama'] = 'Kata sandi saat ini tidak sesuai.';
    }
    if ($baru !== '' && strlen($baru) < 8) {
        $galat['password_baru'] = 'Kata sandi baru minimal 8 karakter.';
    }

    if (!$galat) {
        try {
            if ($baru !== '') {
                $st = $pdo->prepare('UPDATE admin SET username = ?, password_hash = ? WHERE id = ?');
                $st->execute([$userBaru, password_hash($baru, PASSWORD_DEFAULT), (int) $_SESSION['admin_id']]);
            } else {
                $st = $pdo->prepare('UPDATE admin SET username = ? WHERE id = ?');
                $st->execute([$userBaru, (int) $_SESSION['admin_id']]);
            }
            session_regenerate_id(true);
            flash_set('ok', 'Pengaturan akun disimpan.');
            redirect('pengaturan.php');
        } catch (PDOException $ex) {
            $galat['username'] = $ex->getCode() === '23000' ? 'Username sudah digunakan.' : 'Gagal menyimpan pengaturan.';
        }
    }
    $user = $userBaru;
}

admin_top('Pengaturan', 'pengaturan');
?>
<div class="panel">
  <h2>Akun Admin</h2>
  <form method="post" autocomplete="off">
    <?= csrf_field() ?>
    <div class="field">
      <label for="username">Username</label>
      <input class="input" id="username" name="username" required maxlength="50" value="<?= e($user) ?>">
      <?php if (isset($galat['username'])): ?><div class="field-error"><?= e($galat['username']) ?></div><?php endif; ?>
    </div>
    <div class="field">
      <label for="password_baru">Kata sandi baru</label>
      <input class="input" type="password" id="password_baru" name="password_baru" autocomplete="new-password">
      <div class="bantuan">Kosongkan bila tidak ingin mengganti kata sandi.</div>
      <?php if (isset($galat['password_baru'])): ?><div class="field-error"><?= e($galat['password_baru']) ?></div><?php endif; ?>
    </div>
    <div class="field">
      <label for="password_lama">Kata sandi saat ini (untuk konfirmasi)</label>
      <input class="input" type="password" id="password_lama" name="password_lama" required autocomplete="current-password">
      <?php if (isset($galat['password_lama'])): ?><div class="field-error"><?= e($galat['password_lama']) ?></div><?php endif; ?>
    </div>
    <button type="submit" class="tombol tombol-utama tombol-kecil">Simpan Perubahan</button>
  </form>
</div>
<?php admin_bottom();
