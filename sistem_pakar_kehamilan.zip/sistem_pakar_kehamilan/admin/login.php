<?php
declare(strict_types=1);
require __DIR__ . '/../includes/init.php';

if (!empty($_SESSION['admin_id'])) {
    redirect('index.php');
}

const LOGIN_MAKS_GAGAL = 5;
const LOGIN_JEDA       = 300; // detik

$galat = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_cek();

    $gagal  = (int) ($_SESSION['login_gagal'] ?? 0);
    $sejak  = (int) ($_SESSION['login_sejak'] ?? 0);
    if ($gagal >= LOGIN_MAKS_GAGAL && time() - $sejak < LOGIN_JEDA) {
        $sisa  = LOGIN_JEDA - (time() - $sejak);
        $galat = 'Terlalu banyak percobaan. Coba lagi dalam ' . (int) ceil($sisa / 60) . ' menit.';
    } else {
        if ($gagal >= LOGIN_MAKS_GAGAL) {
            $gagal = 0;
        }
        $user = trim((string) ($_POST['username'] ?? ''));
        $pass = (string) ($_POST['password'] ?? '');

        $st = db()->prepare('SELECT id, username, password_hash, nama FROM admin WHERE username = ?');
        $st->execute([$user]);
        $a = $st->fetch();

        // password_verify tetap dipanggil walau user tidak ada, agar waktu respons seragam.
        $hash = $a['password_hash'] ?? '$2y$10$usesomesillystringforsaltuOzXq1c0g0M0jvQ6F8b9V6vQeQe0hS';
        if (password_verify($pass, $hash) && $a) {
            session_regenerate_id(true);
            unset($_SESSION['login_gagal'], $_SESSION['login_sejak']);
            $_SESSION['admin_id']    = (int) $a['id'];
            $_SESSION['admin_nama']  = $a['nama'];
            $_SESSION['admin_aktif'] = time();
            redirect('index.php');
        }
        $_SESSION['login_gagal'] = $gagal + 1;
        $_SESSION['login_sejak'] = time();
        $galat = 'Username atau kata sandi salah.';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Masuk Admin · Sistem Pakar Kehamilan</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="admin">
<div class="login-wrap">
  <div class="kartu login-kartu">
    <span class="admin-mark"><?= ikon('shield-check', 24) ?></span>
    <h1>Masuk Admin</h1>
    <p class="redup" style="margin-bottom:24px">Panel pengelolaan basis pengetahuan sistem pakar.</p>

    <?php render_flash(); ?>
    <?php if ($galat): ?><div class="notif notif-err" role="alert"><?= e($galat) ?></div><?php endif; ?>

    <form method="post" autocomplete="off">
      <?= csrf_field() ?>
      <div class="field">
        <label for="username">Username</label>
        <input class="input" type="text" id="username" name="username" required autofocus maxlength="50">
      </div>
      <div class="field">
        <label for="password">Kata sandi</label>
        <input class="input" type="password" id="password" name="password" required>
      </div>
      <button type="submit" class="tombol tombol-utama">Masuk</button>
    </form>
    <p style="margin:20px 0 0;text-align:center"><a href="../index.php">&larr; Kembali ke situs</a></p>
  </div>
</div>
</body>
</html>
