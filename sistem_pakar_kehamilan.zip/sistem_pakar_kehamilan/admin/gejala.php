<?php
declare(strict_types=1);
require __DIR__ . '/_auth.php';

$galat = [];
$form  = ['mode' => 'tambah', 'kode_lama' => '', 'kode' => '', 'nama' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_cek();
    $op = (string) ($_POST['op'] ?? '');

    if ($op === 'hapus') {
        $kode = (string) ($_POST['kode'] ?? '');
        $st = $pdo->prepare('DELETE FROM gejala WHERE kode = ?');
        $st->execute([$kode]);
        flash_set('ok', "Gejala $kode dihapus beserta relasinya.");
        redirect('gejala.php');
    }

    if ($op === 'simpan') {
        $form = [
            'mode'      => ($_POST['mode'] ?? '') === 'edit' ? 'edit' : 'tambah',
            'kode_lama' => (string) ($_POST['kode_lama'] ?? ''),
            'kode'      => strtoupper(trim((string) ($_POST['kode'] ?? ''))),
            'nama'      => trim((string) ($_POST['nama'] ?? '')),
        ];
        if (!preg_match('/^(G\d{3}|TEMP_[A-Z0-9]{1,8})$/', $form['kode'])) {
            $galat['kode'] = 'Kode harus berformat G + 3 angka (mis. G045) atau penanda sementara seperti TEMP_PDV.';
        }
        if ($form['nama'] === '' || strlen($form['nama']) > 200) {
            $galat['nama'] = 'Nama gejala wajib diisi (maksimal 200 karakter).';
        }

        if (!$galat) {
            try {
                if ($form['mode'] === 'edit') {
                    // ON UPDATE CASCADE pada tabel relasi ikut memperbarui kode.
                    $st = $pdo->prepare('UPDATE gejala SET kode = ?, nama = ? WHERE kode = ?');
                    $st->execute([$form['kode'], $form['nama'], $form['kode_lama']]);
                    flash_set('ok', 'Data gejala diperbarui.');
                } else {
                    $st = $pdo->prepare('INSERT INTO gejala (kode, nama) VALUES (?, ?)');
                    $st->execute([$form['kode'], $form['nama']]);
                    flash_set('ok', 'Gejala ditambahkan. Hubungkan dengan penyakit di menu Bobot CF Pakar.');
                }
                redirect('gejala.php');
            } catch (PDOException $ex) {
                if ($ex->getCode() === '23000') {
                    $galat['kode'] = 'Kode sudah digunakan.';
                } else {
                    error_log($ex->getMessage());
                    $galat['umum'] = 'Gagal menyimpan data.';
                }
            }
        }
    }
}

$aksi = (string) ($_GET['aksi'] ?? '');
if ($_SERVER['REQUEST_METHOD'] === 'GET' && $aksi === 'edit') {
    $st = $pdo->prepare('SELECT kode, nama FROM gejala WHERE kode = ?');
    $st->execute([(string) ($_GET['kode'] ?? '')]);
    if ($r = $st->fetch()) {
        $form = ['mode' => 'edit', 'kode_lama' => $r['kode'], 'kode' => $r['kode'], 'nama' => $r['nama']];
    } else {
        flash_set('err', 'Gejala tidak ditemukan.');
        redirect('gejala.php');
    }
}
$tampilForm = $aksi === 'tambah' || $aksi === 'edit' || $galat;

if ($tampilForm) {
    admin_top($form['mode'] === 'edit' ? 'Edit Gejala' : 'Tambah Gejala', 'gejala');
    ?>
<div class="panel">
  <?php if (isset($galat['umum'])): ?><div class="notif notif-err"><?= e($galat['umum']) ?></div><?php endif; ?>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="op" value="simpan">
    <input type="hidden" name="mode" value="<?= e($form['mode']) ?>">
    <input type="hidden" name="kode_lama" value="<?= e($form['kode_lama']) ?>">

    <div class="field">
      <label for="kode">Kode</label>
      <input class="input" id="kode" name="kode" maxlength="12" required value="<?= e($form['kode']) ?>" placeholder="G045">
      <?php if (isset($galat['kode'])): ?><div class="field-error"><?= e($galat['kode']) ?></div><?php endif; ?>
      <div class="bantuan">Penanda sementara (mis. TEMP_PDV) dapat diganti menjadi kode G resmi; relasinya ikut terbarui otomatis.</div>
    </div>
    <div class="field">
      <label for="nama">Nama gejala medis</label>
      <input class="input" id="nama" name="nama" maxlength="200" required value="<?= e($form['nama']) ?>">
      <?php if (isset($galat['nama'])): ?><div class="field-error"><?= e($galat['nama']) ?></div><?php endif; ?>
    </div>
    <div class="baris-tombol">
      <button type="submit" class="tombol tombol-utama tombol-kecil">Simpan</button>
      <a class="tombol tombol-kecil" href="gejala.php">Batal</a>
    </div>
  </form>
</div>
<?php
    admin_bottom();
    exit;
}

$daftar = $pdo->query(
    'SELECT g.kode, g.nama, (SELECT COUNT(*) FROM relasi r WHERE r.kode_gejala = g.kode) AS jml
       FROM gejala g ORDER BY g.kode'
)->fetchAll();

admin_top('Kelola Gejala', 'gejala', ['label' => 'Tambah Gejala', 'href' => '?aksi=tambah']);
?>
<div class="tabel-wadah">
  <table class="tabel">
    <thead><tr><th style="width:150px">Kode</th><th>Nama Gejala Medis</th><th style="width:110px">Dipakai pada</th><th style="width:150px">Aksi</th></tr></thead>
    <tbody>
      <?php foreach ($daftar as $d): ?>
        <tr>
          <td><span class="badge-kode"><?= e($d['kode']) ?></span></td>
          <td><?= e($d['nama']) ?></td>
          <td class="redup"><?= (int) $d['jml'] ?> penyakit</td>
          <td>
            <div class="aksi-sel">
              <a class="tautan-aksi" href="?aksi=edit&amp;kode=<?= urlencode($d['kode']) ?>">Edit</a>
              <form method="post" data-konfirmasi="Hapus gejala <?= e($d['kode']) ?> beserta relasinya?">
                <?= csrf_field() ?><input type="hidden" name="op" value="hapus"><input type="hidden" name="kode" value="<?= e($d['kode']) ?>">
                <button type="submit" class="tautan-aksi bahaya">Hapus</button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$daftar): ?><tr><td colspan="4" class="kosong">Belum ada data gejala.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php admin_bottom();
