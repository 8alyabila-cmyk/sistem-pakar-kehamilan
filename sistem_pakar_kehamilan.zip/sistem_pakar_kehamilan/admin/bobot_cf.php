<?php
declare(strict_types=1);
require __DIR__ . '/_auth.php';

/** Normalisasi input CF: terima "0,75" atau "0.75"; hasil 0.01-1.00 atau null bila tidak valid. */
function baca_cf($mentah): ?float
{
    $s = str_replace(',', '.', trim((string) $mentah));
    if ($s === '' || !is_numeric($s)) {
        return null;
    }
    $v = round((float) $s, 2);
    return ($v > 0 && $v <= 1) ? $v : null;
}

$galat = [];
$form  = ['mode' => 'tambah', 'id' => 0, 'penyakit' => '', 'gejala' => '', 'cf' => ''];

$daftarPenyakit = $pdo->query('SELECT kode, nama FROM penyakit ORDER BY kode')->fetchAll();
$daftarGejala   = $pdo->query('SELECT kode, nama FROM gejala ORDER BY kode')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_cek();
    $op = (string) ($_POST['op'] ?? '');

    if ($op === 'hapus') {
        $st = $pdo->prepare('DELETE FROM relasi WHERE id = ?');
        $st->execute([(int) ($_POST['id'] ?? 0)]);
        flash_set('ok', 'Relasi dihapus.');
        redirect('bobot_cf.php' . (!empty($_POST['filter']) ? '?penyakit=' . urlencode((string) $_POST['filter']) : ''));
    }

    if ($op === 'simpan') {
        $form = [
            'mode'     => ($_POST['mode'] ?? '') === 'edit' ? 'edit' : 'tambah',
            'id'       => (int) ($_POST['id'] ?? 0),
            'penyakit' => (string) ($_POST['penyakit'] ?? ''),
            'gejala'   => (string) ($_POST['gejala'] ?? ''),
            'cf'       => trim((string) ($_POST['cf'] ?? '')),
        ];
        $cf = baca_cf($form['cf']);
        if ($cf === null) {
            $galat['cf'] = 'Nilai CF pakar harus berupa angka antara 0,01 dan 1,00.';
        }

        if ($form['mode'] === 'tambah') {
            $kodeP = array_column($daftarPenyakit, 'kode');
            $kodeG = array_column($daftarGejala, 'kode');
            if (!in_array($form['penyakit'], $kodeP, true)) {
                $galat['penyakit'] = 'Pilih penyakit yang valid.';
            }
            if (!in_array($form['gejala'], $kodeG, true)) {
                $galat['gejala'] = 'Pilih gejala yang valid.';
            }
        }

        if (!$galat) {
            try {
                if ($form['mode'] === 'edit') {
                    $st = $pdo->prepare('UPDATE relasi SET cf_pakar = ? WHERE id = ?');
                    $st->execute([$cf, $form['id']]);
                    flash_set('ok', 'Nilai CF pakar diperbarui.');
                } else {
                    $st = $pdo->prepare('INSERT INTO relasi (kode_penyakit, kode_gejala, cf_pakar) VALUES (?, ?, ?)');
                    $st->execute([$form['penyakit'], $form['gejala'], $cf]);
                    flash_set('ok', 'Relasi penyakit-gejala ditambahkan.');
                }
                redirect('bobot_cf.php?penyakit=' . urlencode($form['penyakit']));
            } catch (PDOException $ex) {
                if ($ex->getCode() === '23000') {
                    $galat['gejala'] = 'Pasangan penyakit dan gejala ini sudah ada. Gunakan Edit untuk mengubah nilainya.';
                } else {
                    error_log($ex->getMessage());
                    $galat['umum'] = 'Gagal menyimpan data.';
                }
            }
        }
    }
}

$aksi   = (string) ($_GET['aksi'] ?? '');
$filter = (string) ($_GET['penyakit'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $aksi === 'edit') {
    $st = $pdo->prepare(
        'SELECT r.id, r.kode_penyakit, r.kode_gejala, r.cf_pakar, p.nama AS np, g.nama AS ng
           FROM relasi r JOIN penyakit p ON p.kode = r.kode_penyakit JOIN gejala g ON g.kode = r.kode_gejala
          WHERE r.id = ?'
    );
    $st->execute([(int) ($_GET['id'] ?? 0)]);
    if ($r = $st->fetch()) {
        $form = ['mode' => 'edit', 'id' => (int) $r['id'], 'penyakit' => $r['kode_penyakit'], 'gejala' => $r['kode_gejala'],
                 'cf' => number_format((float) $r['cf_pakar'], 2, '.', ''), 'np' => $r['np'], 'ng' => $r['ng']];
    } else {
        flash_set('err', 'Relasi tidak ditemukan.');
        redirect('bobot_cf.php');
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET' && $aksi === 'tambah') {
    $form['penyakit'] = $filter;
}
$tampilForm = $aksi === 'tambah' || $aksi === 'edit' || $galat;

if ($tampilForm) {
    $edit = $form['mode'] === 'edit';
    admin_top($edit ? 'Edit Bobot CF Pakar' : 'Tambah Relasi', 'bobot');
    ?>
<div class="panel">
  <?php if (isset($galat['umum'])): ?><div class="notif notif-err"><?= e($galat['umum']) ?></div><?php endif; ?>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="op" value="simpan">
    <input type="hidden" name="mode" value="<?= e($form['mode']) ?>">
    <input type="hidden" name="id" value="<?= (int) $form['id'] ?>">

    <?php if ($edit): ?>
      <input type="hidden" name="penyakit" value="<?= e($form['penyakit']) ?>">
      <input type="hidden" name="gejala" value="<?= e($form['gejala']) ?>">
      <div class="field"><span class="label">Penyakit</span><div><span class="badge-kode"><?= e($form['penyakit']) ?></span> <?= e($form['np'] ?? '') ?></div></div>
      <div class="field"><span class="label">Gejala</span><div><span class="badge-kode"><?= e($form['gejala']) ?></span> <?= e($form['ng'] ?? '') ?></div></div>
    <?php else: ?>
      <div class="field">
        <label for="penyakit">Penyakit</label>
        <select class="input" id="penyakit" name="penyakit" required>
          <option value="">— pilih penyakit —</option>
          <?php foreach ($daftarPenyakit as $p): ?>
            <option value="<?= e($p['kode']) ?>"<?= $form['penyakit'] === $p['kode'] ? ' selected' : '' ?>><?= e($p['kode'] . ' — ' . $p['nama']) ?></option>
          <?php endforeach; ?>
        </select>
        <?php if (isset($galat['penyakit'])): ?><div class="field-error"><?= e($galat['penyakit']) ?></div><?php endif; ?>
      </div>
      <div class="field">
        <label for="gejala">Gejala</label>
        <select class="input" id="gejala" name="gejala" required>
          <option value="">— pilih gejala —</option>
          <?php foreach ($daftarGejala as $g): ?>
            <option value="<?= e($g['kode']) ?>"<?= $form['gejala'] === $g['kode'] ? ' selected' : '' ?>><?= e($g['kode'] . ' — ' . $g['nama']) ?></option>
          <?php endforeach; ?>
        </select>
        <?php if (isset($galat['gejala'])): ?><div class="field-error"><?= e($galat['gejala']) ?></div><?php endif; ?>
      </div>
    <?php endif; ?>

    <div class="field">
      <label for="cf">Nilai CF pakar (0,01 – 1,00)</label>
      <input class="input" id="cf" name="cf" inputmode="decimal" required value="<?= e($form['cf']) ?>" placeholder="0,80">
      <?php if (isset($galat['cf'])): ?><div class="field-error"><?= e($galat['cf']) ?></div><?php endif; ?>
    </div>
    <div class="baris-tombol">
      <button type="submit" class="tombol tombol-utama tombol-kecil">Simpan</button>
      <a class="tombol tombol-kecil" href="bobot_cf.php<?= $form['penyakit'] ? '?penyakit=' . urlencode($form['penyakit']) : '' ?>">Batal</a>
    </div>
  </form>
</div>
<?php
    admin_bottom();
    exit;
}

// ---- Daftar relasi (opsional difilter per penyakit) ----
$sql = 'SELECT r.id, r.kode_penyakit, r.kode_gejala, r.cf_pakar, g.nama AS nama_gejala
          FROM relasi r JOIN gejala g ON g.kode = r.kode_gejala';
$par = [];
if ($filter !== '') {
    $sql .= ' WHERE r.kode_penyakit = ?';
    $par[] = $filter;
}
$sql .= ' ORDER BY r.kode_penyakit, r.kode_gejala';
$st = $pdo->prepare($sql);
$st->execute($par);
$daftar = $st->fetchAll();

admin_top('Bobot CF Pakar', 'bobot', ['label' => 'Tambah Relasi', 'href' => '?aksi=tambah' . ($filter !== '' ? '&penyakit=' . urlencode($filter) : '')]);
?>
<form method="get" class="baris-tombol" style="margin-bottom:16px">
  <label for="f" class="sr-only">Filter penyakit</label>
  <select class="input" id="f" name="penyakit" style="max-width:320px" onchange="this.form.submit()">
    <option value="">Semua penyakit</option>
    <?php foreach ($daftarPenyakit as $p): ?>
      <option value="<?= e($p['kode']) ?>"<?= $filter === $p['kode'] ? ' selected' : '' ?>><?= e($p['kode'] . ' — ' . $p['nama']) ?></option>
    <?php endforeach; ?>
  </select>
  <noscript><button class="tombol tombol-kecil" type="submit">Terapkan</button></noscript>
  <span class="redup"><?= count($daftar) ?> relasi</span>
</form>

<div class="tabel-wadah">
  <table class="tabel">
    <thead><tr><th style="width:126px">Penyakit</th><th>Gejala Terkait</th><th style="width:170px">Nilai CF Pakar</th><th style="width:160px">Aksi</th></tr></thead>
    <tbody>
      <?php foreach ($daftar as $d): ?>
        <tr>
          <td><span class="badge-kode"><?= e($d['kode_penyakit']) ?></span></td>
          <td><span class="badge-kode"><?= e($d['kode_gejala']) ?></span> <?= e($d['nama_gejala']) ?></td>
          <td><strong><?= e(number_format((float) $d['cf_pakar'], 2, ',', '.')) ?></strong></td>
          <td>
            <div class="aksi-sel">
              <a class="tautan-aksi" href="?aksi=edit&amp;id=<?= (int) $d['id'] ?>">Edit</a>
              <form method="post" data-konfirmasi="Hapus relasi <?= e($d['kode_penyakit'] . '–' . $d['kode_gejala']) ?>?">
                <?= csrf_field() ?><input type="hidden" name="op" value="hapus"><input type="hidden" name="id" value="<?= (int) $d['id'] ?>"><input type="hidden" name="filter" value="<?= e($filter) ?>">
                <button type="submit" class="tautan-aksi bahaya">Hapus</button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$daftar): ?><tr><td colspan="4" class="kosong">Belum ada relasi.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php admin_bottom();
