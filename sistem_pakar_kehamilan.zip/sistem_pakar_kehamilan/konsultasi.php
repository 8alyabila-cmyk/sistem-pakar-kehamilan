<?php
declare(strict_types=1);
require __DIR__ . '/includes/init.php';

$pdo    = db();
$gejala = $pdo->query('SELECT kode, nama FROM gejala ORDER BY kode')->fetchAll();

// Isi ulang bila pengguna kembali dari halaman tinjauan / ada kesalahan validasi.
$draf    = $_SESSION['konsultasi'] ?? [];
$nama    = (string) ($draf['nama'] ?? '');
$usia    = (string) ($draf['usia'] ?? '');
$jawaban = (array)  ($draf['jawaban'] ?? []);

public_top('Konsultasi', 'konsultasi');
?>
<h1 class="judul-halaman">Konsultasi Gejala</h1>
<p class="sub-halaman">Pilih <strong>Ya</strong> untuk gejala yang sedang Anda alami dan biarkan <strong>Tidak</strong> bila tidak dialami.
  Anda dapat meninjau kembali jawaban sebelum hasil diproses.</p>

<?php if (!$gejala): ?>
  <div class="kartu kartu-isi tidak-ditemukan"><p class="redup">Daftar gejala belum tersedia.</p></div>
<?php else: ?>
<form method="post" action="proses_konsultasi.php" autocomplete="off">
  <?= csrf_field() ?>
  <input type="hidden" name="aksi" value="tinjau">

  <div class="kartu identitas-form">
    <div class="field">
      <label for="nama">Nama ibu hamil</label>
      <input class="input" type="text" id="nama" name="nama" maxlength="100" required value="<?= e($nama) ?>">
    </div>
    <div class="field">
      <label for="usia">Usia kehamilan (minggu)</label>
      <input class="input" type="number" id="usia" name="usia" min="1" max="45" inputmode="numeric" value="<?= e($usia) ?>" placeholder="Opsional">
    </div>
  </div>

  <div class="kartu daftar-gejala" role="group" aria-label="Daftar gejala">
    <?php foreach ($gejala as $g):
        $nilai = (string) ($jawaban[$g['kode']] ?? '0.0'); ?>
      <div class="gejala-item">
        <div class="gejala-info">
          <span class="badge-kode"><?= e($g['kode']) ?></span>
          <label class="gejala-nama" for="g-<?= e($g['kode']) ?>"><?= e($g['nama']) ?></label>
        </div>
        <div class="pilih-wrap">
          <select class="input" id="g-<?= e($g['kode']) ?>" name="jawaban[<?= e($g['kode']) ?>]" data-gejala-select>
            <option value="0.0"<?= '0.0' === $nilai ? ' selected' : '' ?>>Tidak / Tidak Tahu (0.0)</option>
            <option value="0.2"<?= '0.2' === $nilai ? ' selected' : '' ?>>Sedikit Yakin (0.2)</option>
            <option value="0.4"<?= '0.4' === $nilai ? ' selected' : '' ?>>Cukup Yakin (0.4)</option>
            <option value="0.6"<?= '0.6' === $nilai ? ' selected' : '' ?>>Yakin (0.6)</option>
            <option value="0.8"<?= '0.8' === $nilai ? ' selected' : '' ?>>Sangat Yakin (0.8)</option>
            <option value="1.0"<?= '1.0' === $nilai ? ' selected' : '' ?>>Pasti / Sesuai Hasil Dokter (1.0)</option>
          </select>
          <?= ikon('chevron-down', 14) ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  
  <div class="bar-aksi">
    <span><strong id="jumlah-dipilih">0</strong> gejala dipilih</span>
    <button type="submit" class="tombol tombol-utama">Tinjau Jawaban <?= ikon('arrow-right', 18) ?></button>
  </div>
</form>
<?php endif; ?>
<?php public_bottom();
