<?php
declare(strict_types=1);

/**
 * Koneksi database (PDO / MySQL).
 * Sesuaikan konstanta di bawah dengan server MySQL Anda (default XAMPP/Laragon).
 */
const DB_HOST = 'localhost';
const DB_PORT = '3306';
const DB_NAME = 'sistem_pakar_kehamilan';
const DB_USER = 'root';
const DB_PASS = '';

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_PORT, DB_NAME),
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );
            $pdo->exec("SET time_zone = '+07:00'"); // WIB
        } catch (PDOException $e) {
            error_log('Koneksi DB gagal: ' . $e->getMessage());
            http_response_code(500);
            exit('Koneksi database gagal. Periksa pengaturan di koneksi.php dan pastikan MySQL sudah berjalan serta database.sql sudah diimpor.');
        }
    }
    return $pdo;
}
