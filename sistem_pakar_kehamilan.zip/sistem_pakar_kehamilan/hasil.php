<?php
declare(strict_types=1);
require __DIR__ . '/includes/init.php';

$pdo   = db();
$token = (string) ($_GET['t'] ?? '');

$k = null;
if (preg_match('/^[a-f0-9]{32}$/', $token)) {
    $st = $pdo->prepare('SELECT * FROM konsultasi WHERE token = ?');
    $st->execute([$token]);
    $k = $st->fetch();
}

if (!$k) {
    http_response_code(404);
    public_top('Hasil tidak ditemukan', 'konsultasi');
    echo '<div class="kartu kartu-isi tidak-ditemukan"><h2>Hasil tidak ditemukan</h2><p class="redup">Tautan hasil tidak valid atau sudah tidak tersedia.</p><a class="tombol tombol-utama" href="konsultasi.php">Mulai Konsultasi</a></div>';
    public_bottom();
    exit;
}

$id = (int) $k['id'];

$st = $pdo->prepare('SELECT * FROM konsultasi_hasil WHERE id_konsultasi = ? ORDER BY peringkat');
$st->execute([$id]);
$ranking = $st->fetchAll();

$st = $pdo->prepare('SELECT kode_gejala, nama_gejala, cf_user FROM konsultasi_detail WHERE id_konsultasi = ? ORDER BY kode_gejala');
$st->execute([$id]);
$gejalaDipilih = $st->fetchAll();

$top = $ranking[0] ?? null;

// Deskripsi & solusi diambil dari data master terkini (bila penyakit masih ada).
$penyakit = null;
if ($top) {
    $st = $pdo->prepare('SELECT deskripsi, solusi, solusi_tervalidasi FROM penyakit WHERE kode = ?');
    $st->execute([$top['kode_penyakit']]);
    $penyakit = $st->fetch() ?: null;
}
$solusi = ($penyakit && (int) $penyakit['solusi_tervalidasi'] === 1 && trim((string) $penyakit['solusi']) !== '')
    ? (string) $penyakit['solusi'] : null;

$rincian = [];
if ($top && !empty($top['rincian'])) {
    $rincian = json_decode((string) $top['rincian'], true) ?: [];
}
$kat = $top ? kategori_cf((float) $top['cf']) : null;

public_top('Hasil Diagnosis', 'konsultasi');
?>
<div class="tidak-cetak" style="margin-bottom:8px"><a class="tautan-detail" href="index.php">&larr; Beranda</a></div>
<h1 class="judul-halaman">Hasil Diagnosis</h1>
<p class="sub-halaman">
  <?= e($k['nama_ibu']) ?>
  <?= $k['usia_kehamilan'] ? ' · usia kehamilan ' . (int) $k['usia_kehamilan'] . ' minggu' : '' ?>
  · <?= e(tanggal_id($k['dibuat'])) ?>
</p>

<?php if (!$top): ?>
  <div class="kartu kartu-isi tidak-ditemukan">
    <h2>Tidak ada penyakit yang cocok</h2>
    <p class="redup">Gejala yang dipilih tidak terhubung dengan penyakit manapun pada basis pengetahuan.
      Bila keluhan berlanjut, segera periksakan diri ke tenaga kesehatan.</p>
    <a class="tombol tombol-utama" href="konsultasi.php">Konsultasi Ulang</a>
  </div>
<?php else: ?>

  <div class="hasil-utama">
    <div class="kartu kartu-isi">
      <span class="badge-kode"><?= e($top['kode_penyakit']) ?></span>
      <h2><?= e($top['nama_penyakit']) ?></h2>
      <p><?= $penyakit ? e($penyakit['deskripsi']) : '<span class="redup">Deskripsi penyakit tidak lagi tersedia pada data master.</span>' ?></p>

      <div class="kotak-solusi<?= $solusi === null ? ' belum' : '' ?>">
        <span class="label">Solusi medis / tindak lanjut</span>
        <?= $solusi === null ? e(TEKS_SOLUSI_BELUM) : nl2br(e($solusi)) ?>
      </div>
    </div>

    <div class="kartu kartu-isi skor">
      <div class="skor-angka"><?= e(format_persen((float) $top['cf'])) ?></div>
      <div class="skor-cf">CF = <?= e(format_cf((float) $top['cf'])) ?></div>
      <div class="meter" role="img" aria-label="Tingkat keyakinan <?= e(format_persen((float) $top['cf'])) ?>"><span style="width:<?= max(2, min(100, (float) $top['persen'])) ?>%"></span></div>
      <span class="badge-kategori kat-<?= e($kat['kelas']) ?>">Kategori <?= e($kat['label']) ?></span>
      <p class="redup" style="margin:10px 0 0;font-size:13px">Rentang <?= e($kat['rentang']) ?></p>
    </div>
  </div>

  <h2 style="margin-bottom:12px;font-size:18px">Peringkat Diagnosis</h2>
  <div class="tabel-wadah" style="max-width:960px">
    <table class="tabel">
      <thead><tr><th>Peringkat</th><th>Kode</th><th>Nama Penyakit</th><th>Nilai CF</th><th>Persentase</th><th>Kategori</th></tr></thead>
      <tbody>
        <?php foreach ($ranking as $r): $kr = kategori_cf((float) $r['cf']); ?>
          <tr>
            <td><strong><?= (int) $r['peringkat'] ?></strong></td>
            <td><span class="badge-kode"><?= e($r['kode_penyakit']) ?></span></td>
            <td><?= e($r['nama_penyakit']) ?></td>
            <td><?= e(format_cf((float) $r['cf'])) ?></td>
            <td><?= e(format_persen((float) $r['cf'])) ?></td>
            <td><span class="badge-kategori kat-<?= e($kr['kelas']) ?>"><?= e($kr['label']) ?></span></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <div class="dua-kolom">
    <div class="kartu kartu-isi">
      <h3 style="margin-bottom:8px">Gejala yang dipilih</h3>
      <ul class="daftar-bersih">
        <?php foreach ($gejalaDipilih as $g): ?>
          <li><span class="badge-kode"><?= e($g['kode_gejala']) ?></span><span><?= e($g['nama_gejala']) ?></span></li>
        <?php endforeach; ?>
      </ul>
    </div>
    <?php if ($rincian): ?>
    <div class="kartu kartu-isi">
      <h3 style="margin-bottom:8px">Rincian perhitungan <?= e($top['kode_penyakit']) ?></h3>
      <div class="tabel-wadah" style="border:0">
        <table class="tabel kecil">
          <thead><tr><th>Gejala</th><th>CF pakar</th><th>CF user</th><th>CF(H,E)</th><th>CF gabungan</th></tr></thead>
          <tbody>
            <?php foreach ($rincian as $b): ?>
              <tr>
                <td><span class="badge-kode"><?= e($b['kode']) ?></span></td>
                <td><?= e(number_format((float) $b['cf_pakar'], 2, ',', '.')) ?></td>
                <td><?= e(number_format((float) $b['cf_user'], 2, ',', '.')) ?></td>
                <td><?= e(format_cf((float) $b['cf_he'])) ?></td>
                <td><?= e(format_cf((float) $b['cf_kum'])) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <p class="redup" style="font-size:13px;margin:10px 0 0">CF(H,E) = CF pakar × CF user · CF gabungan = CF₁ + CF₂ × (1 − CF₁)</p>
    </div>
    <?php endif; ?>
  </div>

  <div class="catatan-medis">
    <?= ikon('triangle-alert', 20) ?>
    <div>Hasil ini adalah perkiraan sistem pakar dan <strong>bukan diagnosis pasti</strong>. Konsultasikan dengan dokter atau bidan.
      Segera cari pertolongan medis bila terdapat perdarahan banyak, nyeri perut hebat, kejang, atau penurunan kesadaran.</div>
  </div>

  <div class="baris-tombol tidak-cetak" style="margin-top:24px">
    <button type="button" class="tombol" data-cetak><?= ikon('printer', 18) ?> Cetak Hasil</button>
    <a class="tombol tombol-utama" href="konsultasi.php"><?= ikon('rotate-ccw', 18) ?> Konsultasi Ulang</a>
  </div>
<?php endif; ?>
<?php public_bottom();
