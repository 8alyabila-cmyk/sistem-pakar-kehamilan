<?php
declare(strict_types=1);
require __DIR__ . '/includes/init.php';

$draf = $_SESSION['konsultasi'] ?? null;
if (!$draf || empty($draf['jawaban'])) {
    flash_set('err', 'Belum ada jawaban untuk ditinjau. Silakan isi konsultasi terlebih dahulu.');
    redirect('konsultasi.php');
}

$pdo    = db();
$nama   = $pdo->query('SELECT kode, nama FROM gejala ORDER BY kode')->fetchAll(PDO::FETCH_KEY_PAIR);
$dipilih = [];
$tidak   = 0;
foreach ($draf['jawaban'] as $kode => $cf) {
    if (!isset($nama[$kode])) {
        continue;
    }
    if ((float) $cf > 0) {
        $dipilih[$kode] = (string) $cf;
    } else {
        $tidak++;
    }
}

public_top('Tinjauan Jawaban', 'konsultasi');
?>
<h1 class="judul-halaman">Tinjauan Jawaban</h1>
<p class="sub-halaman">Periksa kembali data dan gejala berikut. Jika sudah sesuai, lanjutkan untuk melihat hasil diagnosis.</p>

<div class="kartu kartu-isi" style="max-width:960px;margin-bottom:24px">
  <div class="dua-kolom" style="margin-top:0">
    <div><span class="redup">Nama ibu hamil</span><br><strong><?= e($draf['nama']) ?></strong></div>
    <div><span class="redup">Usia kehamilan</span><br><strong><?= $draf['usia'] !== '' ? e($draf['usia']) . ' minggu' : '-' ?></strong></div>
  </div>
</div>

<div class="kartu tabel-wadah" style="max-width:960px">
  <table class="tabel">
    <thead><tr><th style="width:120px">Kode</th><th>Gejala yang dialami</th><th style="width:160px">Jawaban</th></tr></thead>
    <tbody>
      <?php foreach ($dipilih as $kode => $cf): ?>
        <tr>
          <td><span class="badge-kode"><?= e($kode) ?></span></td>
          <td><?= e($nama[$kode]) ?></td>
          <td><strong><?= e(CF_USER_OPSI[$cf] ?? $cf) ?></strong></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$dipilih): ?>
        <tr><td colspan="3" class="kosong">Tidak ada gejala yang dipilih.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<p class="redup" style="margin-top:12px"><?= count($dipilih) ?> gejala dipilih · <?= $tidak ?> gejala dijawab "Tidak".</p>

<div class="baris-tombol" style="margin-top:20px">
  <a class="tombol" href="konsultasi.php">Ubah Jawaban</a>
  <?php if ($dipilih): ?>
    <form method="post" action="proses_konsultasi.php" style="margin:0">
      <?= csrf_field() ?>
      <input type="hidden" name="aksi" value="proses">
      <button type="submit" class="tombol tombol-utama">Lihat Hasil Diagnosis <?= ikon('arrow-right', 18) ?></button>
    </form>
  <?php endif; ?>
</div>
<?php public_bottom();
