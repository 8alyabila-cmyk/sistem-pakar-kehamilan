<?php
declare(strict_types=1);
require __DIR__ . '/includes/init.php';

/**
 * Menangani dua tahap:
 *   aksi=tinjau  -> validasi jawaban formulir, simpan ke sesi, arahkan ke tinjauan.php
 *   aksi=proses  -> jalankan forward chaining + CF dari jawaban di sesi,
 *                   simpan riwayat ke database, arahkan ke hasil.php
 */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('konsultasi.php');
}
csrf_cek();

$pdo  = db();
$aksi = (string) ($_POST['aksi'] ?? '');

/* ------------------------------------------------------------
 *  TAHAP 1: validasi & simpan sementara di sesi
 * ------------------------------------------------------------ */
if ($aksi === 'tinjau') {
    $nama = trim((string) ($_POST['nama'] ?? ''));
    $usia = trim((string) ($_POST['usia'] ?? ''));
    $kirim = $_POST['jawaban'] ?? [];
    $kirim = is_array($kirim) ? $kirim : [];

    $galat = [];
    $len   = function_exists('mb_strlen') ? mb_strlen($nama) : strlen($nama);
    if ($len < 2 || $len > 100) {
        $galat[] = 'Nama harus diisi (2-100 karakter).';
    }
    if ($usia !== '' && (!ctype_digit($usia) || (int) $usia < 1 || (int) $usia > 45)) {
        $galat[] = 'Usia kehamilan harus berupa angka 1-45 minggu.';
    }

   // Daftar opsi valid secara langsung untuk memastikan amannya validasi
    $opsiValid = ['0.0', '0.2', '0.4', '0.6', '0.8', '1.0'];

    $kodeValid = $pdo->query('SELECT kode FROM gejala')->fetchAll(PDO::FETCH_COLUMN);
    $jawaban   = [];
    foreach ($kodeValid as $kode) {
        $v = $kirim[$kode] ?? '0.0';
        $v = is_scalar($v) ? (string) $v : '0.0';
        // Validasi apakah nilai yang dikirim ada di dalam daftar opsi yang diizinkan
        $jawaban[$kode] = in_array($v, $opsiValid, true) ? $v : '0.0';
    }

    $adaGejala = false;
    foreach ($jawaban as $v) {
        if ((float) $v > 0.0) {
            $adaGejala = true;
            break;
        }
    }
    if (!$adaGejala) {
        $galat[] = 'Pilih minimal satu gejala yang Anda alami.';
    }

    $_SESSION['konsultasi'] = ['nama' => $nama, 'usia' => $usia, 'jawaban' => $jawaban];

    if ($galat) {
        foreach ($galat as $g) {
            flash_set('err', $g);
        }
        redirect('konsultasi.php');
    }
    redirect('tinjauan.php');
}

/* ------------------------------------------------------------
 *  TAHAP 2: hitung diagnosis & simpan riwayat
 * ------------------------------------------------------------ */
if ($aksi === 'proses') {
    $draf = $_SESSION['konsultasi'] ?? null;
    if (!$draf || empty($draf['jawaban'])) {
        flash_set('err', 'Data konsultasi tidak ditemukan. Silakan isi ulang.');
        redirect('konsultasi.php');
    }

    $hasil = jalankan_diagnosis($pdo, $draf['jawaban']);
    $top   = $hasil[0] ?? null;
    $token = bin2hex(random_bytes(16));
    $usia  = $draf['usia'] !== '' ? (int) $draf['usia'] : null;

    $namaGejala = $pdo->query('SELECT kode, nama FROM gejala')->fetchAll(PDO::FETCH_KEY_PAIR);

    try {
        $pdo->beginTransaction();

        $st = $pdo->prepare(
            'INSERT INTO konsultasi
               (token, nama_ibu, usia_kehamilan, diagnosis_kode, diagnosis_nama,
                diagnosis_cf, diagnosis_persen, diagnosis_kategori)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $st->execute([
            $token,
            $draf['nama'],
            $usia,
            $top['kode'] ?? null,
            $top['nama'] ?? null,
            $top['cf'] ?? 0,
            $top['persen'] ?? 0,
            $top['kategori']['label'] ?? null,
        ]);
        $idKonsultasi = (int) $pdo->lastInsertId();

        $stD = $pdo->prepare(
            'INSERT INTO konsultasi_detail (id_konsultasi, kode_gejala, nama_gejala, cf_user) VALUES (?, ?, ?, ?)'
        );
        foreach ($draf['jawaban'] as $kode => $cfUser) {
            if ((float) $cfUser > 0 && isset($namaGejala[$kode])) {
                $stD->execute([$idKonsultasi, $kode, $namaGejala[$kode], $cfUser]);
            }
        }

        $stH = $pdo->prepare(
            'INSERT INTO konsultasi_hasil
               (id_konsultasi, peringkat, kode_penyakit, nama_penyakit, cf, persen, kategori, rincian)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );
        foreach ($hasil as $h) {
            $stH->execute([
                $idKonsultasi,
                $h['peringkat'],
                $h['kode'],
                $h['nama'],
                $h['cf'],
                $h['persen'],
                $h['kategori']['label'],
                json_encode($h['jejak'], JSON_UNESCAPED_UNICODE),
            ]);
        }

        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('Simpan konsultasi gagal: ' . $e->getMessage());
        flash_set('err', 'Terjadi kesalahan saat menyimpan hasil. Silakan coba lagi.');
        redirect('tinjauan.php');
    }

    unset($_SESSION['konsultasi']);
    redirect('hasil.php?t=' . $token);
}

redirect('konsultasi.php');
