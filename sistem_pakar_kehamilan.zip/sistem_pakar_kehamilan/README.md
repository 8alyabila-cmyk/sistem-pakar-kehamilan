# Sistem Pakar Diagnosis Gangguan Kehamilan (Certainty Factor)

Aplikasi web PHP + MySQL. Metode: **Forward Chaining** + **Certainty Factor**.
Persyaratan: PHP 8.1+ (ekstensi `pdo_mysql`), MySQL 5.7+/MariaDB 10.3+. Tanpa framework dan tanpa dependensi luar.

## Instalasi (XAMPP / Laragon)

1. Salin folder `sistem_pakar_kehamilan` ke `htdocs` (XAMPP) atau `www` (Laragon).
2. Impor `database.sql` lewat phpMyAdmin (tab *Import*) atau `mysql -u root -p < database.sql`.
3. Sesuaikan `koneksi.php` bila user/password MySQL Anda bukan `root` / kosong.
4. Buka `http://localhost/sistem_pakar_kehamilan/`.
5. Admin: `http://localhost/sistem_pakar_kehamilan/admin/login.php`
   Akun awal **admin / admin123**. Segera ganti di menu *Pengaturan*.

## Struktur

```
sistem_pakar_kehamilan/
├── database.sql            Skema + data awal (7 tabel)
├── koneksi.php             Koneksi PDO MySQL
├── index.php               Beranda (kartu 8 penyakit, tautan Detail Medis)
├── detail_penyakit.php     Detail medis satu penyakit
├── konsultasi.php          Form konsultasi (daftar gejala + pilihan Ya/Tidak)
├── proses_konsultasi.php   Validasi jawaban -> sesi; hitung CF -> simpan riwayat
├── tinjauan.php            Tinjauan jawaban sebelum diproses
├── hasil.php               Hasil diagnosis (cetak / konsultasi ulang)
├── includes/
│   ├── init.php            Sesi, header keamanan, require pustaka
│   ├── fungsi.php          Helper, CSRF, ikon, MESIN CF (jalankan_diagnosis)
│   └── layout.php          Template publik & admin
├── admin/
│   ├── login.php  logout.php  _auth.php
│   ├── index.php           Dashboard
│   ├── penyakit.php        CRUD penyakit
│   ├── gejala.php          CRUD gejala
│   ├── bobot_cf.php        Relasi penyakit-gejala + nilai CF pakar
│   ├── aturan.php          Manajemen aturan IF-THEN (dibangkitkan dari relasi)
│   ├── solusi.php          Solusi medis + status validasi pakar
│   ├── riwayat.php         Riwayat diagnosis
│   └── pengaturan.php      Ganti username / kata sandi
└── assets/css/style.css, assets/js/app.js
```

## Cara kerja perhitungan

1. **Fakta**: gejala yang dijawab Ya (CF user = 1).
2. **Aturan menyala**: setiap baris `relasi` yang gejalanya ada di fakta.
3. `CF(H,E) = CF_pakar × CF_user`
4. Untuk penyakit yang sama: `CF_combine = CF1 + CF2 × (1 − CF1)`
5. Persentase = `CF_akhir × 100%`. Penyakit diurutkan dari CF tertinggi.

Rincian langkah perhitungan penyakit teratas ditampilkan di halaman hasil.

## Hal yang perlu Anda putuskan / lengkapi

| Hal | Keterangan |
|---|---|
| **Data gejala & bobot CF** | Dokumen acuan tidak tersedia saat kode dibuat. G001–G044, relasi, dan nilai `cf_pakar` di `database.sql` adalah **data contoh**. Ganti lewat menu *Kelola Gejala* dan *Bobot CF Pakar* atau edit file SQL sebelum dipakai nyata. |
| **TEMP_PDV** | Ada sebagai gejala biasa. Ganti kodenya menjadi kode G resmi di *Kelola Gejala → Edit*; relasi ikut berubah otomatis (`ON UPDATE CASCADE`). |
| **Kategori** | Rentang jurnal tumpang tindih (Low 0–0,4 · Med 0,3–0,7 · High 0,6–1,0). Agar hasil selalu satu kategori, dipakai titik tengah daerah tumpang tindih: CF < 0,35 Rendah, < 0,65 Sedang, ≥ 0,65 Tinggi. Ubah di `includes/fungsi.php` (`BATAS_*`). |
| **Solusi medis** | Semua penyakit dibuat *belum tervalidasi* sehingga pengguna melihat `[Materi tindak lanjut menunggu validasi pakar medis]`. Isi dan centang "tervalidasi" di *Solusi Medis*. |
| **Pilihan jawaban** | Sesuai spesifikasi: Ya = 1, Tidak = 0 (dropdown seperti desain Figma). Tingkat keyakinan lain cukup ditambah di konstanta `CF_USER_OPSI`. |

## Keamanan yang sudah diterapkan

PDO prepared statements, `password_hash`, `session_regenerate_id` saat login, token CSRF di semua form POST, escape keluaran (`htmlspecialchars`), pembatasan percobaan login (5× / 5 menit), logout via POST, idle timeout admin 2 jam, hasil publik diakses lewat token acak 32 hex (bukan ID berurutan). Untuk produksi: gunakan HTTPS, akun MySQL non-root, dan ganti kata sandi admin.
