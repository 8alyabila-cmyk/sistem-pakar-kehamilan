-- ============================================================
--  Sistem Pakar Diagnosis Gangguan Kehamilan (Certainty Factor)
--  Skema + data awal.  Kompatibel MySQL 5.7+ / MariaDB 10.3+
--  Impor:  mysql -u root -p < database.sql
--  atau lewat phpMyAdmin > Import.
--
--  CATATAN PENTING:
--  * Daftar gejala (G001-G044), relasi, dan nilai cf_pakar di bawah adalah
--    DATA CONTOH agar aplikasi langsung bisa dijalankan. Samakan dengan
--    dokumen acuan / validasi pakar medis melalui menu admin
--    (Kelola Gejala, Bobot CF Pakar) sebelum aplikasi dipakai sungguhan.
--  * Materi solusi medis sengaja belum diisi (menunggu validasi pakar).
--  * Akun admin awal:  admin / admin123  -> WAJIB diganti di menu Pengaturan.
-- ============================================================

CREATE DATABASE IF NOT EXISTS sistem_pakar_kehamilan
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sistem_pakar_kehamilan;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS konsultasi_hasil;
DROP TABLE IF EXISTS konsultasi_detail;
DROP TABLE IF EXISTS konsultasi;
DROP TABLE IF EXISTS relasi;
DROP TABLE IF EXISTS gejala;
DROP TABLE IF EXISTS penyakit;
DROP TABLE IF EXISTS admin;
SET FOREIGN_KEY_CHECKS = 1;

-- ------------------------------------------------------------
-- Akun admin
-- ------------------------------------------------------------
CREATE TABLE admin (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(50)  NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  nama          VARCHAR(100) NOT NULL,
  dibuat        TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Penyakit (8 gangguan kehamilan, Tabel 1 jurnal)
-- ------------------------------------------------------------
CREATE TABLE penyakit (
  kode               VARCHAR(10)  NOT NULL PRIMARY KEY,
  nama               VARCHAR(120) NOT NULL,
  deskripsi          TEXT         NOT NULL,
  solusi             TEXT         NULL,
  solusi_tervalidasi TINYINT(1)   NOT NULL DEFAULT 0,
  diperbarui         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Gejala (G001..G044 + penanda sementara TEMP_PDV)
-- ------------------------------------------------------------
CREATE TABLE gejala (
  kode VARCHAR(15)  NOT NULL PRIMARY KEY,
  nama VARCHAR(200) NOT NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Relasi penyakit-gejala + bobot CF pakar  (basis aturan IF-THEN)
-- ------------------------------------------------------------
CREATE TABLE relasi (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  kode_penyakit  VARCHAR(10)  NOT NULL,
  kode_gejala    VARCHAR(15)  NOT NULL,
  cf_pakar       DECIMAL(3,2) NOT NULL,
  UNIQUE KEY uq_relasi (kode_penyakit, kode_gejala),
  CONSTRAINT chk_cf_pakar CHECK (cf_pakar > 0 AND cf_pakar <= 1),
  CONSTRAINT fk_relasi_penyakit FOREIGN KEY (kode_penyakit) REFERENCES penyakit(kode)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_relasi_gejala FOREIGN KEY (kode_gejala) REFERENCES gejala(kode)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Riwayat konsultasi.
-- Nama penyakit/gejala disimpan sebagai salinan (snapshot) supaya
-- riwayat tetap utuh walau data master diubah atau dihapus.
-- ------------------------------------------------------------
CREATE TABLE konsultasi (
  id                 INT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  token              CHAR(32)      NOT NULL UNIQUE,
  nama_ibu           VARCHAR(100)  NOT NULL,
  usia_kehamilan     SMALLINT      NULL,
  diagnosis_kode     VARCHAR(10)   NULL,
  diagnosis_nama     VARCHAR(120)  NULL,
  diagnosis_cf       DECIMAL(8,6)  NOT NULL DEFAULT 0,
  diagnosis_persen   DECIMAL(5,2)  NOT NULL DEFAULT 0,
  diagnosis_kategori VARCHAR(10)   NULL,
  dibuat             TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_dibuat (dibuat)
) ENGINE=InnoDB;

CREATE TABLE konsultasi_detail (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  id_konsultasi  INT UNSIGNED NOT NULL,
  kode_gejala    VARCHAR(15)  NOT NULL,
  nama_gejala    VARCHAR(200) NOT NULL,
  cf_user        DECIMAL(3,2) NOT NULL,
  CONSTRAINT fk_detail_konsultasi FOREIGN KEY (id_konsultasi) REFERENCES konsultasi(id)
    ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE konsultasi_hasil (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  id_konsultasi  INT UNSIGNED NOT NULL,
  peringkat      SMALLINT     NOT NULL,
  kode_penyakit  VARCHAR(10)  NOT NULL,
  nama_penyakit  VARCHAR(120) NOT NULL,
  cf             DECIMAL(8,6) NOT NULL,
  persen         DECIMAL(5,2) NOT NULL,
  kategori       VARCHAR(10)  NOT NULL,
  rincian        TEXT         NULL,
  CONSTRAINT fk_hasil_konsultasi FOREIGN KEY (id_konsultasi) REFERENCES konsultasi(id)
    ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
--  DATA AWAL
-- ============================================================

INSERT INTO admin (username, password_hash, nama) VALUES
('admin', '$2y$10$laQnXxgxn4TWjs/7isb3W.yXaBg8DDS8f9Ye4rWFzMjKq/GAJwfia', 'Administrator');

INSERT INTO penyakit (kode, nama, deskripsi, solusi, solusi_tervalidasi) VALUES
('P001', 'Mola Hidatidosa',
 'Kehamilan abnormal ketika jaringan plasenta tumbuh berlebihan menyerupai gelembung-gelembung dan janin tidak berkembang normal.',
 NULL, 0),
('P002', 'Hiperemesis Gravidarum',
 'Mual dan muntah berat yang berlebihan selama kehamilan sehingga dapat menyebabkan dehidrasi dan penurunan berat badan.',
 NULL, 0),
('P003', 'Blighted Ovum',
 'Kondisi ketika kantung kehamilan terbentuk di dalam rahim tetapi embrio tidak berkembang di dalamnya.',
 NULL, 0),
('P004', 'Preeklamsia',
 'Gangguan kehamilan berupa tekanan darah tinggi yang disertai tanda gangguan organ, umumnya muncul setelah usia kehamilan 20 minggu.',
 NULL, 0),
('P005', 'Solusio Plasenta',
 'Terlepasnya plasenta dari dinding rahim sebelum bayi dilahirkan, yang dapat mengganggu pasokan oksigen janin.',
 NULL, 0),
('P006', 'Kehamilan Ektopik',
 'Hasil pembuahan menempel dan tumbuh di luar rongga rahim, paling sering di saluran tuba.',
 NULL, 0),
('P007', 'Eklamsia',
 'Kejang pada ibu hamil dengan preeklamsia yang tidak disebabkan oleh penyebab lain; merupakan kegawatdaruratan kebidanan.',
 NULL, 0),
('P008', 'Plasenta Previa',
 'Kondisi ketika plasenta menutupi sebagian atau seluruh jalan lahir (mulut rahim bagian dalam).',
 NULL, 0);

-- Daftar gejala (DATA CONTOH - sesuaikan dengan dokumen acuan)
INSERT INTO gejala (kode, nama) VALUES
('G001', 'Mual berlebihan'),
('G002', 'Muntah terus-menerus'),
('G003', 'Penurunan berat badan'),
('G004', 'Dehidrasi (mulut kering, jarang buang air kecil)'),
('G005', 'Tubuh terasa lemas'),
('G006', 'Pusing'),
('G007', 'Nyeri kepala hebat'),
('G008', 'Pandangan kabur'),
('G009', 'Nyeri ulu hati'),
('G010', 'Pembengkakan pada wajah'),
('G011', 'Pembengkakan pada tangan dan kaki'),
('G012', 'Kenaikan berat badan mendadak'),
('G013', 'Tekanan darah tinggi'),
('G014', 'Protein dalam urine'),
('G015', 'Kejang'),
('G016', 'Penurunan kesadaran'),
('G017', 'Nyeri perut bagian bawah'),
('G018', 'Nyeri perut tajam pada satu sisi'),
('G019', 'Nyeri pada bahu'),
('G020', 'Nyeri perut hebat yang mendadak'),
('G021', 'Perut terasa tegang dan kaku'),
('G022', 'Rahim lebih besar dari usia kehamilan'),
('G023', 'Keluar jaringan menyerupai anggur dari vagina'),
('G024', 'Gerakan janin tidak terasa'),
('G025', 'Detak jantung janin tidak terdengar'),
('G026', 'Rahim lebih kecil dari usia kehamilan'),
('G027', 'Nyeri punggung'),
('G028', 'Kram perut'),
('G029', 'Keluar cairan dari vagina'),
('G030', 'Kantung kehamilan kosong pada pemeriksaan USG'),
('G031', 'Janin tidak tampak pada pemeriksaan USG'),
('G032', 'Kadar hCG sangat tinggi'),
('G033', 'Kadar hCG rendah atau tidak naik'),
('G034', 'Jantung berdebar'),
('G035', 'Sesak napas'),
('G036', 'Kulit tampak pucat'),
('G037', 'Keringat dingin'),
('G038', 'Tekanan darah rendah'),
('G039', 'Denyut nadi cepat'),
('G040', 'Kontraksi rahim'),
('G041', 'Perdarahan tanpa disertai nyeri'),
('G042', 'Plasenta letak rendah pada pemeriksaan USG'),
('G043', 'Posisi janin sungsang atau melintang'),
('G044', 'Riwayat operasi caesar'),
('TEMP_PDV', 'Perdarahan dari vagina');

-- Relasi & bobot CF pakar (NILAI CONTOH - ganti dengan nilai dari pakar)
INSERT INTO relasi (kode_penyakit, kode_gejala, cf_pakar) VALUES
-- P001 Mola Hidatidosa
('P001','G001',0.40),('P001','G013',0.40),('P001','G022',0.70),('P001','G023',0.90),
('P001','G025',0.60),('P001','G032',0.80),('P001','TEMP_PDV',0.60),
-- P002 Hiperemesis Gravidarum
('P002','G001',0.60),('P002','G002',0.90),('P002','G003',0.70),('P002','G004',0.70),
('P002','G005',0.50),('P002','G006',0.40),
-- P003 Blighted Ovum
('P003','G026',0.50),('P003','G028',0.40),('P003','G030',0.90),('P003','G031',0.80),
('P003','G033',0.60),('P003','TEMP_PDV',0.50),
-- P004 Preeklamsia
('P004','G007',0.60),('P004','G008',0.60),('P004','G009',0.50),('P004','G010',0.50),
('P004','G011',0.50),('P004','G012',0.40),('P004','G013',0.90),('P004','G014',0.90),
-- P005 Solusio Plasenta
('P005','G016',0.40),('P005','G020',0.80),('P005','G021',0.80),('P005','G025',0.40),
('P005','G038',0.50),('P005','G039',0.50),('P005','G040',0.50),('P005','TEMP_PDV',0.70),
-- P006 Kehamilan Ektopik
('P006','G017',0.60),('P006','G018',0.80),('P006','G019',0.50),('P006','G031',0.50),
('P006','G033',0.60),('P006','G036',0.40),('P006','G037',0.40),('P006','G038',0.50),
('P006','G039',0.40),('P006','TEMP_PDV',0.70),
-- P007 Eklamsia
('P007','G007',0.50),('P007','G008',0.40),('P007','G013',0.80),('P007','G014',0.70),
('P007','G015',0.90),('P007','G016',0.80),
-- P008 Plasenta Previa
('P008','G040',0.30),('P008','G041',0.90),('P008','G042',0.90),('P008','G043',0.50),
('P008','G044',0.40),('P008','TEMP_PDV',0.70);
