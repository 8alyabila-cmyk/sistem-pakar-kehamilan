/* Skrip ringan: penghitung gejala, konfirmasi hapus, cetak. */
(function () {
  'use strict';

  // Halaman konsultasi: sorot baris yang dijawab "Ya" + hitung jumlahnya.
  var daftar = document.querySelectorAll('[data-gejala-select]');
  var penghitung = document.getElementById('jumlah-dipilih');
  function segarkan() {
    var n = 0;
    daftar.forEach(function (sel) {
      var aktif = parseFloat(sel.value) > 0;
      if (aktif) { n++; }
      var baris = sel.closest('.gejala-item');
      if (baris) { baris.classList.toggle('dipilih', aktif); }
    });
    if (penghitung) { penghitung.textContent = String(n); }
  }
  daftar.forEach(function (sel) { sel.addEventListener('change', segarkan); });
  if (daftar.length) { segarkan(); }

  // Konfirmasi sebelum menghapus (form dengan data-konfirmasi="pesan").
  document.addEventListener('submit', function (ev) {
    var f = ev.target;
    var pesan = f && f.getAttribute ? f.getAttribute('data-konfirmasi') : null;
    if (pesan && !window.confirm(pesan)) { ev.preventDefault(); }
  });

  // Tombol cetak.
  document.querySelectorAll('[data-cetak]').forEach(function (el) {
    el.addEventListener('click', function () { window.print(); });
  });
})();
