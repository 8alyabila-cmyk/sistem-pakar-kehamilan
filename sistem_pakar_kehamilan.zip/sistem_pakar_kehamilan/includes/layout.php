<?php
declare(strict_types=1);

function render_flash(): void
{
    foreach (flash_ambil() as $f) {
        $kelas = $f['tipe'] === 'ok' ? 'notif-ok' : 'notif-err';
        echo '<div class="notif ' . $kelas . '" role="status">' . e($f['pesan']) . '</div>';
    }
}

/* ------------------------------------------------------------
 *  LAYOUT PUBLIK
 * ------------------------------------------------------------ */

function public_top(string $judul, string $aktif = '', string $root = ''): void
{
    $nav = [
        'beranda'   => ['Beranda', 'index.php'],
        'konsultasi' => ['Konsultasi', 'konsultasi.php'],
    ];
    ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($judul) ?> · Sistem Pakar Kehamilan</title>
<link rel="stylesheet" href="<?= e($root) ?>assets/css/style.css">
</head>
<body class="publik">
<header class="topbar">
  <div class="wadah topbar-in">
    <a class="brand" href="<?= e($root) ?>index.php">
      <span class="brand-mark"><?= ikon('stethoscope', 22) ?></span>
      <span class="brand-teks"><strong>Pakar Kehamilan</strong><small>Diagnosis dengan Certainty Factor</small></span>
    </a>
    <nav class="topnav" aria-label="Navigasi utama">
      <?php foreach ($nav as $kunci => [$label, $href]): ?>
        <a href="<?= e($root . $href) ?>"<?= $aktif === $kunci ? ' class="aktif" aria-current="page"' : '' ?>><?= e($label) ?></a>
      <?php endforeach; ?>
      <a class="topnav-admin" href="<?= e($root) ?>admin/login.php"><?= ikon('shield-check', 16) ?> Admin</a>
    </nav>
  </div>
</header>
<main class="wadah utama">
<?php render_flash();
}

function public_bottom(string $root = ''): void
{
    ?>
</main>
<footer class="footer">
  <div class="wadah">
    <p>Sistem pakar ini bersifat membantu dan <strong>bukan pengganti pemeriksaan serta diagnosis dokter</strong>.
       Bila Anda mengalami perdarahan, nyeri hebat, kejang, atau penurunan kesadaran, segera ke fasilitas kesehatan terdekat.</p>
  </div>
</footer>
<script src="<?= e($root) ?>assets/js/app.js"></script>
</body>
</html>
<?php
}

/* ------------------------------------------------------------
 *  LAYOUT ADMIN  (sidebar 256px seperti pada Figma)
 * ------------------------------------------------------------ */

/**
 * @param array{label:string,href:string}|null $aksi  tombol aksi pada header halaman
 */
function admin_top(string $judul, string $aktif, ?array $aksi = null): void
{
    $menu = [
        'dashboard' => ['Dashboard',         'index.php',    'layout-dashboard'],
        'penyakit'  => ['Kelola Penyakit',   'penyakit.php', 'stethoscope'],
        'gejala'    => ['Kelola Gejala',     'gejala.php',   'list-checks'],
        'bobot'     => ['Bobot CF Pakar',    'bobot_cf.php', 'sliders-horizontal'],
        'aturan'    => ['Aturan IF-THEN',    'aturan.php',   'git-fork'],
        'solusi'    => ['Solusi Medis',      'solusi.php',   'file-text'],
        'riwayat'   => ['Riwayat Diagnosis', 'riwayat.php',  'history'],
    ];
    ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?= e($judul) ?> · Admin Pakar Kehamilan</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="admin">
<div class="admin-grid">
  <aside class="sidebar">
    <div class="sidebar-identitas">
      <span class="admin-mark"><?= ikon('shield-check', 24) ?></span>
      <span class="identitas-teks"><strong>Panel Admin</strong><small><?= e($_SESSION['admin_nama'] ?? 'Dokter') ?></small></span>
    </div>
    <hr class="pemisah">
    <nav class="sidebar-menu" aria-label="Menu admin">
      <?php foreach ($menu as $kunci => [$label, $href, $ik]): ?>
        <a class="nav-item<?= $aktif === $kunci ? ' aktif' : '' ?>" href="<?= e($href) ?>"<?= $aktif === $kunci ? ' aria-current="page"' : '' ?>>
          <?= ikon($ik, 20) ?><span><?= e($label) ?></span>
        </a>
      <?php endforeach; ?>
    </nav>
    <div class="sidebar-akun">
      <a class="nav-item nav-kecil<?= $aktif === 'pengaturan' ? ' aktif' : '' ?>" href="pengaturan.php">
        <?= ikon('settings', 20) ?><span>Pengaturan</span>
      </a>
      <form method="post" action="logout.php">
        <?= csrf_field() ?>
        <button type="submit" class="nav-item nav-kecil nav-tombol"><?= ikon('log-out', 20) ?><span>Keluar</span></button>
      </form>
    </div>
  </aside>

  <div class="admin-konten">
    <div class="halaman-header">
      <h1><?= e($judul) ?></h1>
      <?php if ($aksi): ?>
        <a class="tombol tombol-utama tombol-kecil" href="<?= e($aksi['href']) ?>"><?= ikon('plus', 16) ?> <?= e($aksi['label']) ?></a>
      <?php endif; ?>
    </div>
    <?php render_flash();
}

function admin_bottom(): void
{
    ?>
  </div>
</div>
<script src="../assets/js/app.js"></script>
</body>
</html>
<?php
}
