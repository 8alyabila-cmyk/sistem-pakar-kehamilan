<?php
declare(strict_types=1);

/* ============================================================
 *  KONFIGURASI METODE
 * ============================================================ */

/**
 * Pilihan jawaban pengguna -> nilai CF user.
 * Sesuai spesifikasi: Ya = 1, Tidak = 0.
 * Untuk menambah tingkat keyakinan (mis. "Mungkin" = 0.6) cukup tambah baris
 * di sini, mis. '0.6' => 'Mungkin'. Dropdown di halaman konsultasi ikut berubah.
 */
const CF_USER_OPSI = [
    '0' => 'Tidak',
    '1' => 'Ya',
];

/**
 * Kategori hasil. Rentang pada jurnal saling tumpang tindih:
 *   Rendah 0.0-0.4 | Sedang 0.3-0.7 | Tinggi 0.6-1.0
 * Agar kategori selalu tunggal, di daerah tumpang tindih dipakai titik tengahnya:
 *   CF < 0.35  -> Rendah
 *   CF < 0.65  -> Sedang
 *   CF >= 0.65 -> Tinggi
 */
const BATAS_RENDAH_SEDANG = 0.35;
const BATAS_SEDANG_TINGGI = 0.65;

const TEKS_SOLUSI_BELUM = '[Materi tindak lanjut menunggu validasi pakar medis]';

/* ============================================================
 *  HELPER UMUM
 * ============================================================ */

function e($nilai): string
{
    return htmlspecialchars((string) $nilai, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $url): never
{
    header('Location: ' . $url);
    exit;
}

function flash_set(string $tipe, string $pesan): void
{
    $_SESSION['flash'][] = ['tipe' => $tipe, 'pesan' => $pesan];
}

function flash_ambil(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_cek(): void
{
    $kirim = $_POST['csrf'] ?? '';
    if (!is_string($kirim) || !hash_equals(csrf_token(), $kirim)) {
        http_response_code(419);
        exit('Sesi formulir kedaluwarsa. Silakan kembali, muat ulang halaman, lalu coba lagi.');
    }
}

function tanggal_id(?string $waktu): string
{
    if (!$waktu) {
        return '-';
    }
    $t = strtotime($waktu);
    if ($t === false) {
        return '-';
    }
    $bln = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    return date('j', $t) . ' ' . $bln[(int) date('n', $t) - 1] . ' ' . date('Y, H:i', $t);
}

function format_cf(float $cf): string
{
    return number_format($cf, 4, ',', '.');
}

function format_persen(float $cf): string
{
    return number_format($cf * 100, 2, ',', '.') . '%';
}

/* ============================================================
 *  IKON (gaya Lucide, SVG inline)
 * ============================================================ */

function ikon(string $nama, int $ukuran = 20): string
{
    static $p = [
        'shield-check'       => '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
        'layout-dashboard'   => '<rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/>',
        'stethoscope'        => '<path d="M11 2v2"/><path d="M5 2v2"/><path d="M5 3H4a2 2 0 0 0-2 2v4a6 6 0 0 0 12 0V5a2 2 0 0 0-2-2h-1"/><path d="M8 15a6 6 0 0 0 12 0v-3"/><circle cx="20" cy="10" r="2"/>',
        'list-checks'        => '<path d="m3 17 2 2 4-4"/><path d="m3 7 2 2 4-4"/><path d="M13 6h8"/><path d="M13 12h8"/><path d="M13 18h8"/>',
        'sliders-horizontal' => '<line x1="21" x2="14" y1="4" y2="4"/><line x1="10" x2="3" y1="4" y2="4"/><line x1="21" x2="12" y1="12" y2="12"/><line x1="8" x2="3" y1="12" y2="12"/><line x1="21" x2="16" y1="20" y2="20"/><line x1="12" x2="3" y1="20" y2="20"/><line x1="14" x2="14" y1="2" y2="6"/><line x1="8" x2="8" y1="10" y2="14"/><line x1="16" x2="16" y1="18" y2="22"/>',
        'git-fork'           => '<circle cx="12" cy="18" r="3"/><circle cx="6" cy="6" r="3"/><circle cx="18" cy="6" r="3"/><path d="M18 9v2c0 .6-.4 1-1 1H7c-.6 0-1-.4-1-1V9"/><path d="M12 12v3"/>',
        'file-text'          => '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/>',
        'history'            => '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>',
        'settings'           => '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
        'log-out'            => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/>',
        'plus'               => '<path d="M5 12h14"/><path d="M12 5v14"/>',
        'arrow-right'        => '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
        'chevron-down'       => '<path d="m6 9 6 6 6-6"/>',
        'printer'            => '<path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6"/><rect x="6" y="14" width="12" height="8" rx="1"/>',
        'rotate-ccw'         => '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/>',
        'triangle-alert'     => '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
        'check'              => '<path d="M20 6 9 17l-5-5"/>',
    ];
    if (!isset($p[$nama])) {
        return '';
    }
    return '<svg class="ikon" width="' . $ukuran . '" height="' . $ukuran . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p[$nama] . '</svg>';
}

/* ============================================================
 *  MESIN INFERENSI: FORWARD CHAINING + CERTAINTY FACTOR
 * ============================================================ */

/** CF_combine = CF1 + CF2 * (1 - CF1) */
function cf_gabung(float $cf1, float $cf2): float
{
    return $cf1 + $cf2 * (1 - $cf1);
}

/** Kategori berdasarkan nilai CF akhir. */
function kategori_cf(float $cf): array
{
    $cf = round($cf, 6);
    if ($cf < BATAS_RENDAH_SEDANG) {
        return ['label' => 'Rendah', 'kelas' => 'rendah', 'rentang' => '0,0 - 0,4'];
    }
    if ($cf < BATAS_SEDANG_TINGGI) {
        return ['label' => 'Sedang', 'kelas' => 'sedang', 'rentang' => '0,3 - 0,7'];
    }
    return ['label' => 'Tinggi', 'kelas' => 'tinggi', 'rentang' => '0,6 - 1,0'];
}

/**
 * Menjalankan diagnosis.
 *
 * @param array<string,float|int|string> $jawaban  kode_gejala => CF user (0 = tidak ada)
 * @return array<int,array>  daftar penyakit terurut dari CF tertinggi
 *
 * Forward chaining:
 *   1. Working memory  = gejala dengan CF user > 0 (fakta).
 *   2. Agenda          = aturan IF gejala THEN penyakit yang premisnya ada di fakta.
 *   3. Setiap aturan yang "menyala" menghasilkan CF(H,E) = CF_pakar x CF_user.
 *   4. CF antar aturan untuk penyakit yang sama digabung dengan rumus combine.
 */
function jalankan_diagnosis(PDO $pdo, array $jawaban): array
{
    // 1. Working memory
    $fakta = [];
    foreach ($jawaban as $kode => $nilai) {
        $cfUser = (float) $nilai;
        if ($cfUser > 0) {
            $fakta[(string) $kode] = $cfUser;
        }
    }
    if (!$fakta) {
        return [];
    }

    // Jumlah gejala per penyakit (untuk informasi "x dari y gejala cocok")
    $total = $pdo->query('SELECT kode_penyakit, COUNT(*) AS n FROM relasi GROUP BY kode_penyakit')
                 ->fetchAll(PDO::FETCH_KEY_PAIR);

    // 2. Agenda: aturan yang cocok dengan fakta
    $in = implode(',', array_fill(0, count($fakta), '?'));
    $st = $pdo->prepare(
        "SELECT r.kode_penyakit, r.kode_gejala, r.cf_pakar,
                p.nama AS nama_penyakit, g.nama AS nama_gejala
           FROM relasi r
           JOIN penyakit p ON p.kode = r.kode_penyakit
           JOIN gejala   g ON g.kode = r.kode_gejala
          WHERE r.kode_gejala IN ($in)
          ORDER BY r.kode_penyakit, r.kode_gejala"
    );
    $st->execute(array_keys($fakta));

    // 3 & 4. Menyalakan aturan + menggabungkan CF
    $hasil = [];
    foreach ($st->fetchAll() as $aturan) {
        $kp       = $aturan['kode_penyakit'];
        $cfPakar  = (float) $aturan['cf_pakar'];
        $cfUser   = $fakta[$aturan['kode_gejala']];
        $cfHE     = $cfPakar * $cfUser;

        if (!isset($hasil[$kp])) {
            $hasil[$kp] = [
                'kode'          => $kp,
                'nama'          => $aturan['nama_penyakit'],
                'cf'            => 0.0,
                'gejala_cocok'  => 0,
                'gejala_total'  => (int) ($total[$kp] ?? 0),
                'jejak'         => [],
            ];
        }
        $sebelum = $hasil[$kp]['cf'];
        $sesudah = $hasil[$kp]['gejala_cocok'] === 0 ? $cfHE : cf_gabung($sebelum, $cfHE);

        $hasil[$kp]['cf'] = $sesudah;
        $hasil[$kp]['gejala_cocok']++;
        $hasil[$kp]['jejak'][] = [
            'kode'     => $aturan['kode_gejala'],
            'nama'     => $aturan['nama_gejala'],
            'cf_pakar' => $cfPakar,
            'cf_user'  => $cfUser,
            'cf_he'    => $cfHE,
            'cf_kum'   => $sesudah,
        ];
    }

    $daftar = array_values($hasil);
    usort($daftar, static function (array $a, array $b): int {
        return [$b['cf'], $a['kode']] <=> [$a['cf'], $b['kode']];
    });

    foreach ($daftar as $i => &$d) {
        $d['cf']        = round($d['cf'], 6);
        $d['persen']    = round($d['cf'] * 100, 2);
        $d['kategori']  = kategori_cf($d['cf']);
        $d['peringkat'] = $i + 1;
    }
    unset($d);

    return $daftar;
}
