<?php
declare(strict_types=1);
require __DIR__ . '/includes/init.php';

$pdo      = db();
$penyakit = $pdo->query('SELECT kode, nama, deskripsi FROM penyakit ORDER BY kode')->fetchAll();

public_top('Beranda', 'beranda');
?>
<section class="hero">
  <h1>Sistem Pakar Diagnosis Gangguan Kehamilan</h1>
  <p>Pilih gejala yang Anda rasakan, lalu sistem akan menghitung tingkat keyakinan terhadap delapan gangguan kehamilan
     menggunakan metode <strong>Certainty Factor</strong>.</p>
  <div class="baris-tombol">
    <a class="tombol tombol-utama" href="konsultasi.php">Mulai Konsultasi <?= ikon('arrow-right', 18) ?></a>
  </div>
</section>

<section class="seksi" aria-labelledby="judul-langkah">
  <div class="seksi-judul"><h2 id="judul-langkah">Cara menggunakan</h2></div>
  <div class="langkah">
    <div class="kartu"><div class="no">1</div><h3>Isi data &amp; gejala</h3>
      <p class="redup">Masukkan nama, lalu jawab Ya atau Tidak untuk setiap gejala.</p></div>
    <div class="kartu"><div class="no">2</div><h3>Tinjau jawaban</h3>
      <p class="redup">Periksa kembali gejala yang dipilih sebelum diproses.</p></div>
    <div class="kartu"><div class="no">3</div><h3>Lihat hasil</h3>
      <p class="redup">Diagnosis tertinggi, persentase keyakinan, dan tindak lanjut ditampilkan.</p></div>
  </div>
</section>

<section class="seksi" aria-labelledby="judul-penyakit">
  <div class="seksi-judul"><h2 id="judul-penyakit">Gangguan kehamilan yang dikenali</h2></div>
  <div class="grid-penyakit">
    <?php foreach ($penyakit as $p): ?>
      <article class="kartu kartu-penyakit">
        <span class="badge-kode"><?= e($p['kode']) ?></span>
        <h3><?= e($p['nama']) ?></h3>
        <p><?= e($p['deskripsi']) ?></p>
        <a class="tautan-detail" href="detail_penyakit.php?kode=<?= urlencode($p['kode']) ?>">Detail Medis <?= ikon('arrow-right', 14) ?></a>
      </article>
    <?php endforeach; ?>
    <?php if (!$penyakit): ?>
      <p class="redup">Data penyakit belum tersedia. Impor <code>database.sql</code> terlebih dahulu.</p>
    <?php endif; ?>
  </div>
</section>
<?php public_bottom();
