<?php
declare(strict_types=1);
require __DIR__ . '/includes/init.php';

$pdo  = db();
$kode = (string) ($_GET['kode'] ?? '');
$st   = $pdo->prepare('SELECT * FROM penyakit WHERE kode = ?');
$st->execute([$kode]);
$p = $st->fetch();

if (!$p) {
    http_response_code(404);
    public_top('Tidak ditemukan', 'beranda');
    echo '<div class="kartu kartu-isi tidak-ditemukan"><h2>Penyakit tidak ditemukan</h2><p class="redup">Data yang Anda cari tidak tersedia.</p><a class="tombol" href="index.php">Kembali ke Beranda</a></div>';
    public_bottom();
    exit;
}

$st = $pdo->prepare(
    'SELECT g.kode, g.nama FROM relasi r JOIN gejala g ON g.kode = r.kode_gejala
      WHERE r.kode_penyakit = ? ORDER BY g.kode'
);
$st->execute([$kode]);
$gejala = $st->fetchAll();

$solusi = ((int) $p['solusi_tervalidasi'] === 1 && trim((string) $p['solusi']) !== '')
    ? (string) $p['solusi'] : null;

public_top($p['nama'], 'beranda');
?>
<p><a class="tautan-detail" href="index.php">&larr; Kembali ke Beranda</a></p>
<div class="kartu kartu-isi" style="max-width:860px;margin-top:12px">
  <span class="badge-kode"><?= e($p['kode']) ?></span>
  <h1 style="margin:12px 0 10px;color:var(--maroon)"><?= e($p['nama']) ?></h1>
  <p><?= e($p['deskripsi']) ?></p>

  <div class="kotak-solusi<?= $solusi === null ? ' belum' : '' ?>">
    <span class="label">Solusi medis / tindak lanjut</span>
    <?= $solusi === null ? e(TEKS_SOLUSI_BELUM) : nl2br(e($solusi)) ?>
  </div>

  <h2 style="margin:28px 0 8px;font-size:18px">Gejala terkait</h2>
  <?php if ($gejala): ?>
    <ul class="daftar-bersih">
      <?php foreach ($gejala as $g): ?>
        <li><span class="badge-kode"><?= e($g['kode']) ?></span><span><?= e($g['nama']) ?></span></li>
      <?php endforeach; ?>
    </ul>
  <?php else: ?>
    <p class="redup">Belum ada gejala yang dihubungkan dengan penyakit ini.</p>
  <?php endif; ?>

  <div class="baris-tombol" style="margin-top:24px">
    <a class="tombol tombol-utama" href="konsultasi.php">Mulai Konsultasi</a>
  </div>
</div>
<?php public_bottom();
